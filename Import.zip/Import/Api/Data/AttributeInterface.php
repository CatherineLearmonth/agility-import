<?php

namespace Agility\Import\Api\Data;

interface AttributeInterface
{
    /**
     *
     * @api
     * @return string
     */
    public function getName();

    /**
     *
     * @api
     * @param string $name
     * @return $this
     */
    public function setName($name);

    /**
     *
     * @api
     * @return string
     */
    public function getValue();

    /**
     *
     * @api
     * @param string $value
     * @return $this
     */
    public function setValue($value);

    /**
     *
     * @api
     * @return string
     */
    public function getType();

    /**
     *
     * @api
     * @param string $type
     * @return $this
     */
    public function setType($type);
}
