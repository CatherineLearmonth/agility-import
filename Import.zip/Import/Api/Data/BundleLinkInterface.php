<?php

namespace Agility\Import\Api\Data;

interface BundleLinkInterface
{

    /**
     *
     * @api
     * @return $string
     */
    public function getSku();

    /**
     *
     * @api
     * @param string $sku
     * @return $this
     */
    public function setSku($sku);
    /**
     *
     * @api
     * @return $string
     */
    public function getQuantity();

    /**
     *
     * @api
     * @param string $quantity
     * @return $this
     */
    public function setQuantity($quantity);

     /**
     *
     * @api
     * @return $string
     */
    public function getCanChangeQuantity();

    /**
     *
     * @api
     * @param string $canChangeQuantity
     * @return $this
     */
    public function setCanChangeQuantity($canChangeQuantity);

    /**
     *
     * @api
     * @return $string
     */
    public function getIsDefault();

    /**
     *
     * @api
     * @param string $isDefault
     * @return $this
     */
    public function setIsDefault($isDefault);

    /**
     *
     * @api
     * @return $string
     */
    public function getPrice();

    /**
     *
     * @api
     * @param string $price
     * @return $this
     */
    public function setPrice($price);

}
