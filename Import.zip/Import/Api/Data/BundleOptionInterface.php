<?php

namespace Agility\Import\Api\Data;

interface BundleOptionInterface
{
    /**
     *
     * @api
     * @return $string
     */
    public function getTitle();

    /**
     *
     * @api
     * @param string $title
     * @return $this
     */
    public function setTitle($title);

    /**
     *
     * @api
     * @return $string
     */
    public function getType();

    /**
     *
     * @api
     * @param string $type
     * @return $this
     */
    public function setType($type);

    /**
     *
     * @api
     * @return $string
     */
    public function getPriceType();

    /**
     *
     * @api
     * @param string $priceType
     * @return $this
     */
    public function setPriceType($priceType);

    /**
     *
     * @api
     * @return $string
     */
    public function getIsRequired();

    /**
     *
     * @api
     * @param string $isRequired
     * @return $this
     */
    public function setIsRequired($isRequired);

    /**
     *
     * @api
     * @return $string
     */
    public function getShipmentType();

    /**
     *
     * @api
     * @param string $shipmentType
     * @return $this
     */
    public function setShipmentType($shipmentType);
}
