<?php

namespace Agility\Import\Api\Data;

interface CategoryInterface
{
    /**#@+
     * Constants for keys of data array. Identical to the getters in snake case
     */
    const NAME = 'name';
    const AGILITYID = 'agility_id';
    const PRODUCT = 'product';
    const PRODUCTS = 'products';
    const CATEGORY = 'category';
    const CATEGORIES = 'categories';
    /**#@-*/

    /**
     *
     * @api
     * @return string
     */
    public function getName();

    /**
     *
     * @api
     * @param string $name
     * @return $this
     */
    public function setName($name);

    /**
     *
     * @api
     * @return string
     */
    public function getAgilityId();

    /**
     *
     * @api
     * @param string $agilityId
     * @return $this
     */
    public function setAgilityId($agilityId);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ProductInterface
     */
    public function getProduct();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ProductInterface $product
     * @return $this
     */
    public function setProduct($product);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ProductInterface[]
     */
    public function getProducts();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ProductInterface[] $products
     * @return $this
     */
    public function setProducts(array $products);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\CategoryInterface
     */
    public function getCategory();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\CategoryInterface $category
     * @return $this
     */
    public function setCategory($category);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\CategoryInterface[]
     */
    public function getCategories();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\CategoryInterface[] $categories
     * @return $this
     */
    public function setCategories(array $categories);

}
