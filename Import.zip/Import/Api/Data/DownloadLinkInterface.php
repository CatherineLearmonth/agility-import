<?php

namespace Agility\Import\Api\Data;

interface DownloadLinkInterface
{

    /**
     *
     * @api
     * @return string
     */
    public function getTitle();

    /**
     *
     * @api
     * @param string $title
     * @return $this
     */
    public function setTitle($title);

    /**
     *
     * @api
     * @return string
     */
    public function getIsshareable();

    /**
     *
     * @api
     * @param string $isshareable
     * @return $this
     */
    public function setIsshareable($isshareable);

    /**
     *
     * @api
     * @return string
     */
    public function getPrice();

    /**
     *
     * @api
     * @param string $price
     * @return $this
     */
    public function setPrice($price);

    /**
     *
     * @api
     * @return string
     */
    public function getNumdownloads();

    /**
     *
     * @api
     * @param string $numdownloads
     * @return $this
     */
    public function setNumdownloads($numdownloads);

    /**
     *
     * @api
     * @return string
     */
    public function getLinksamplepath();

    /**
     *
     * @api
     * @param string $linksamplepath
     * @return $this
     */
    public function setLinksamplepath($linksamplepath);

    /**
     *
     * @api
     * @return string
     */
    public function getImagepath();

    /**
     *
     * @api
     * @param string $imagepath
     * @return $this
     */
    public function setImagepath($imagepath);

    /**
     *
     * @api
     * @return string
     */
    public function getImagename();

    /**
     *
     * @api
     * @param string $imagename
     * @return $this
     */
    public function setImagename($imagename);

    /**
     *
     * @api
     * @return string
     */
    public function getLinksamplename();

    /**
     *
     * @api
     * @param string $linksamplename
     * @return $this
     */
    public function setLinksamplename($linksamplename);

    /**
     *
     * @api
     * @return string
     */
    public function getPurchasedseparately();

    /**
     *
     * @api
     * @param string $purchasedseparately
     * @return $this
     */
    public function setPurchasedseparately($purchasedseparately);
}
