<?php

namespace Agility\Import\Api\Data;

interface DownloadSampleInterface
{
    /**
     *
     * @api
     * @return string
     */
    public function getTitle();

    /**
     *
     * @api
     * @param string $title
     * @return $this
     */
    public function setTitle($title);

    /**
     *
     * @api
     * @return string
     */
    public function getSamplepath();

    /**
     *
     * @api
     * @param string $samplepath
     * @return $this
     */
    public function setSamplepath($samplepath);

    /**
     *
     * @api
     * @return string
     */
    public function getSamplename();

    /**
     *
     * @api
     * @param string $samplename
     * @return $this
     */
    public function setSamplename($samplename);

}
