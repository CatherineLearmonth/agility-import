<?php

namespace Agility\Import\Api\Data;

interface ExportInterface
{
    /**#@+
     * Constants for keys of data array. Identical to the getters in snake case
     */
    const CATEGORY = 'category';
    const CATEGORIES = 'categories';
    const PRODUCT = 'product';
    const PRODUCTS = 'products';
    const OPTION = 'option';
    const OPTIONS = 'options';
    /**#@-*/

    /**
     * getCategory
     *
     * @return Agility\Import\Api\Data\CategoryInterface
     */
    public function getCategory();

    /**
     * setCategory
     *
     * @param Agility\Import\Api\Data\CategoryInterface $category
     * @return $this
     */
    public function setCategory($category);

    /**
     * getCategories
     *
     * @return Agility\Import\Api\Data\CategoryInterface[]
     */
    public function getCategories();

    /**
     * setCategories
     *
     * @param Agility\Import\Api\Data\CategoryInterface[] $categories
     * @return $this
     */
    public function setCategories(array $categories);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ProductInterface
     */
    public function getProduct();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ProductInterface $product
     * @return $this
     */
    public function setProduct($product);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ProductInterface[]
     */
    public function getProducts();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ProductInterface[] $products
     * @return $this
     */
    public function setProducts(array $products);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\OptionInterface
     */
    public function getOption();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\OptionInterface $option
     * @return $this
     */
    public function setOption($option);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\OptionInterface[]
     */
    public function getOptions();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\OptionInterface[] $options
     * @return $this
     */
    public function setOptions(array $options);
}
