<?php

namespace Agility\Import\Api\Data;

interface ImageInterface
{
    /**
     *
     * @api
     * @return string
     */
    public function getType();

    /**
     *
     * @api
     * @param string $type
     * @return $this
     */
    public function setType($type);

    /**
     *
     * @api
     * @return string
     */
    public function getPath();

    /**
     *
     * @api
     * @param string $path
     * @return $this
     */
    public function setPath($path);

    /**
     *
     * @api
     * @return string
     */
    public function getLabel();

    /**
     *
     * @api
     * @param string $label
     * @return $this
     */
    public function setLabel($label);

    /**
     *
     * @api
     * @return string
     */
    public function getFiletype();

    /**
     *
     * @api
     * @param string $filetype
     * @return $this
     */
    public function setFiletype($filetype);
}
