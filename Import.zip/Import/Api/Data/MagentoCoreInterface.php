<?php

namespace Agility\Import\Api\Data;

interface MagentoCoreInterface
{

    /**
     *
     * @api
     * @return string
     */
    public function getName();

    /**
     *
     * @api
     * @param string $name
     * @return $this
     */
    public function setName($name);

    /**
     *
     * @api
     * @return string
     */
    public function getSku();

    /**
     *
     * @api
     * @param string $sku
     * @return $this
     */
    public function setSku($sku);
    /**
     *
     * @api
     * @return string
     */
    public function getPrice();

    /**
     *
     * @api
     * @param string $price
     * @return $this
     */
    public function setPrice($price);

    /**
     *
     * @api
     * @return string
     */
    public function getWeight();

    /**
     *
     * @api
     * @param string $weight
     * @return $this
     */
    public function setWeight($weight);

    /**
     *
     * @api
     * @return string
     */
    public function getAttributesetname();

    /**
     *
     * @api
     * @param string $attributesetname
     * @return $this
     */
    public function setAttributesetname($attributesetname);

    /**
     *
     * @api
     * @return string
     */
    public function getInstock();

    /**
     *
     * @api
     * @param string $instock
     * @return $this
     */
    public function setInstock($instock);

    /**
     *
     * @api
     * @return string
     */
    public function getQuantity();

    /**
     *
     * @api
     * @param string $quantity
     * @return $this
     */
    public function setQuantity($quantity);

    /**
     *
     * @api
     * @return string
     */
    public function getStatus();

    /**
     *
     * @api
     * @param string $status
     * @return $this
     */
    public function setStatus($status);

    /**
     *
     * @api
     * @return string
     */
    public function getType();

    /**
     *
     * @api
     * @param string $type
     * @return $this
     */
    public function setType($type);
}
