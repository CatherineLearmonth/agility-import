<?php

namespace Agility\Import\Api\Data;

interface OptionInterface
{

    /**#@+
     * Constants for keys of data array. Identical to the getters in snake case
     */
    const NAME = 'name';
    const AGILITYID = 'agility_id';
    const SALESCATEGORY = 'sales_category';
    const MAGENTOCORE = 'magento_core';
    const ATTRIBUTE = 'attribute';
    const ATTRIBUTES = 'attributes';
    const IMAGE = 'image';
    const IMAGES = 'images';
    const PARENTAGILITYID = 'parent_agility_id';
    /**#@-*/

    /**
     *
     * @api
     * @return string
     */
    public function getName();

    /**
     *
     * @api
     * @param string $name
     * @return $this
     */
    public function setName($name);

    /**
     *
     * @api
     * @return string
     */
    public function getAgilityId();

    /**
     *
     * @api
     * @param string $agilityId
     * @return $this
     */
    public function setAgilityId($agilityId);

    /**
     *
     * @api
     * @return string
     */
    public function getParentAgilityId();

    /**
     *
     * @api
     * @param string $parentAgilityId
     * @return $this
     */
    public function setParentAgilityId($parentAgilityId);

    /**
     *
     * @api
     * @return string
     */
    public function getSalesCategory();

    /**
     *
     * @api
     * @param string $salesCategory
     * @return $this
     */
    public function setSalesCategory($salesCategory);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\MagentoCoreInterface
     */
    public function getMagentoCore();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\MagentoCoreInterface $magentoCore
     * @return $this
     */
    public function setMagentoCore($magentoCore);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\AttributeInterface
     */
    public function getAttribute();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\AttributeInterface $attribute
     * @return $this
     */
    public function setAttribute($attribute);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\AttributeInterface[]
     */
    public function getAttributes();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\AttributeInterface[] $attributes
     * @return $this
     */
    public function setAttributes(array $attributes);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ImageInterface
     */
    public function getImage();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ImageInterface $image
     * @return $this
     */
    public function setImage($image);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ImageInterface[]
     */
    public function getImages();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ImageInterface[] $images
     * @return $this
     */
    public function setImages(array $images);
}
