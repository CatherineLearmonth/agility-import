<?php

namespace Agility\Import\Api\Data;

interface ProductInterface
{
    /**#@+
     * Constants for keys of data array. Identical to the getters in snake case
     */
    const NAME = 'name';
    const AGILITYID = 'agility_id';
    const PARENTAGILITYID = 'parent_agility_id';
    const SALESCATEGORY = 'sales_category';
    const RELATEDSKU = 'related_sku';
    const RELATEDSKUS = 'related_skus';
    const GROUP = 'group';
    const GROUPS = 'groups';
    const MAGENTOCORE = 'magento_core';
    const ATTRIBUTE = 'attribute';
    const ATTRIBUTES = 'attributes';
    const IMAGE = 'image';
    const IMAGES = 'images';
    const OPTION = 'option';
    const OPTIONS = 'options';
    const DOWNLOADSAMPLE = 'downloadsample';
    const DOWNLOADSAMPLES = 'downloadsamples';
    const DOWNLOADLINK = 'downloadlink';
    const DOWNLOADLINKS = 'downloadlinks';
    const BUNDLEOPTION = 'bundle_option';
    const BUNDLELINK = 'bundlelink';
    const BUNDLELINKS = 'bundlelinks';

    /**#@-*/

    /**
     *
     * @api
     * @return string
     */
    public function getName();

    /**
     *
     * @api
     * @param string $name
     * @return $this
     */
    public function setName($name);

    /**
     *
     * @api
     * @return string
     */
    public function getAgilityId();

    /**
     *
     * @api
     * @param string $agilityId
     * @return $this
     */
    public function setAgilityId($agilityId);

    /**
     *
     * @api
     * @return string
     */
    public function getParentAgilityId();

    /**
     *
     * @api
     * @param string $parentAgilityId
     * @return $this
     */
    public function setParentAgilityId($parentAgilityId);

    /**
     *
     * @api
     * @return string
     */
    public function getSalesCategory();

    /**
     *
     * @api
     * @param string $salesCategory
     * @return $this
     */
    public function setSalesCategory($salesCategory);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\MagentoCoreInterface
     */
    public function getMagentoCore();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\MagentoCoreInterface $magentoCore
     * @return $this
     */
    public function setMagentoCore($magentoCore);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\AttributeInterface
     */
    public function getAttribute();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\AttributeInterface $attribute
     * @return $this
     */
    public function setAttribute($attribute);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\AttributeInterface[]
     */
    public function getAttributes();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\AttributeInterface[] $attributes
     * @return $this
     */
    public function setAttributes(array $attributes);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ImageInterface
     */
    public function getImage();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ImageInterface $image
     * @return $this
     */
    public function setImage($image);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ImageInterface[]
     */
    public function getImages();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ImageInterface[] $images
     * @return $this
     */
    public function setImages(array $images);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\OptionInterface
     */
    public function getOption();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\OptionInterface $option
     * @return $this
     */
    public function setOption($option);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\OptionInterface[]
     */
    public function getOptions();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\OptionInterface[] $options
     * @return $this
     */
    public function setOptions(array $options);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\RelatedSkuInterface
     */
    public function getRelatedSku();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\RelatedSkuInterface $relatedSku
     * @return $this
     */
    public function setRelatedSku($relatedSku);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\RelatedSkuInterface[]
     */
    public function getRelatedSkus();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\RelatedSkuInterface[] $relatedSkus
     * @return $this
     */
    public function setRelatedSkus(array $relatedSkus);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\RelatedSkuInterface
     */
    public function getGroup();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\RelatedSkuInterface $group
     * @return $this
     */
    public function setGroup($group);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\RelatedSkuInterface[]
     */
    public function getGroups();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\RelatedSkuInterface[] $groups
     * @return $this
     */
    public function setGroups(array $groups);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\DownloadLinkInterface
     */
    public function getDownloadlink();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\DownloadLinkInterface $downloadlink
     * @return $this
     */
    public function setDownloadlink($downloadlink);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\DownloadLinkInterface[]
     */
    public function getDownloadlinks();

    /**
    *
    * @api
    * @param Agility\Import\Api\Data\DownloadLinkInterface[] $downloadlinks
    * @return $this
    */
    public function setDownloadlinks(array $downloadlinks);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\DownloadSampleInterface
     */
    public function getDownloadsample();

    /**
    *
    * @api
    * @param Agility\Import\Api\Data\DownloadSampleInterface $downloadsample
    * @return $this
    */
    public function setDownloadsample($downloadsample);

    /**
    *
    * @api
    * @return Agility\Import\Api\Data\DownloadSampleInterface[]
    */
    public function getDownloadsamples();

    /**
    *
    * @api
    * @param Agility\Import\Api\Data\DownloadSampleInterface[] $downloadsamples
    * @return $this
    */
    public function setDownloadsamples(array $downloadsamples);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\BundleOptionInterface
     */
    public function getBundleOption();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\BundleOptionInterface $bundleOption
     * @return $this
     */
    public function setBundleOption($bundleOption);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\BundleLinkInterface
     */
    public function getBundleLink();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\BundleLinkInterface $bundleLink
     * @return $this
     */
    public function setBundleLink($bundleLink);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\BundleLinkInterface[]
     */
    public function getBundleLinks();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\BundleLinkInterface[] $bundleLinks
     * @return $this
     */
    public function setBundleLinks(array $bundleLinks);
}
