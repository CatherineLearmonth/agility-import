<?php

namespace Agility\Import\Api\Data;

interface RelatedSkuInterface
{

    /**#@+
     * Constants for keys of data array. Identical to the getters in snake case
     */
    const ATTRIBUTE = 'attribute';
    const ATTRIBUTES = 'attributes';
    /**#@-*/

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\AttributeInterface
     */
    public function getAttribute();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\AttributeInterface $attribute
     * @return $this
     */
    public function setAttribute($attribute);

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\AttributeInterface[]
     */
    public function getAttributes();

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\AttributeInterface[] $attributes
     * @return $this
     */
    public function setAttributes(array $attributes);

}
