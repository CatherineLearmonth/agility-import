<?php

namespace Agility\Import\Api;

interface ImportInterface
{
    /**
     * Create
     *
     * @api
     * @param Agility\Import\Api\Data\ExportInterface $agilityExport
     * @return $this
     */
    public function create($agilityExport);

    /**
     * Delete
     *
     * @api
     * @param Agility\Import\Api\Data\ExportInterface $agilityExport
     * @return $this
     */
    public function delete($agilityExport);

    /**
     * Move
     *
     * @api
     * @param Agility\Import\Api\Data\ExportInterface $agilityExport
     * @return $this
     */
    public function move($agilityExport);

    /**
     * Link
     *
     * @api
     * @param Agility\Import\Api\Data\ExportInterface $agilityExport
     * @return $this
     */
    public function link($agilityExport);

    /**
     * Unlink
     *
     * @api
     * @param Agility\Import\Api\Data\ExportInterface $agilityExport
     * @return $this
     */
    public function unlink($agilityExport);

        /**
         * CreateCategory
         *
         * @api
         * @return $webapicall
         */
    public function createCategory($category, $parentObj);

     /**
      * processAttributes
      * @api
      * @return $this
      */
    public function processAttributes($category);

    /**
     * getMagentoAttribs
     * @api
     * @return $this
     */
    public function getMagentoAttribs();

    /**
     * convertText
     * @api
     * @return $this
     */
    public function convertText($string);

    /**
     * checkEavAttribute
     * @api
     * @return $this
     */

    public function checkEavAttribute($attribute, $agilityObj);

    /**
     * checkArray
     * @api
     * @return $this
     */

    public function checkArray($agilityAttrValue);

    /**
     * createLabel
     * @api
     * @return $this
     */

    public function createLabel($string);

    /**
     * createNewAttributeOption
     * @api
     * @return $this
     */

    public function createNewAttributeOption($agilityAttrValue, $id);

    /**
     * checkAgilityAttributes
     * @api
     * @return $this
     */
    public function checkAgilityAttributes($attribute, $agilityObj);

    /**
     * createVariant
     * @api
     * @return $optionId
     */
    public function createVariant($agilityObj);

    /**
     * cleanText
     * @api
     * @return $string
     */
    public function cleanText($string);

    /**
     * setMediaGallery
     * @api
     * @return $mgEntries
     */
    public function setMediaGallery($images, $position, $mgEntries);

    /**
     * processImages
     * @api
     * @return $productObj
     */
    public function processImages($product, $productObj);

    /**
     * processRelations
     * @api
     * @return $productObj
     */
    public function processRelations($product);

    /**
     * getMagentoAttribSets
     *
     * @api
     * @return $this
     */
    public function getMagentoAttribSets($attrSetName);

    /**
     * setDownloadable
     *
     * @api
     * @return $this
     */
    public function setDownloadable($agilityProduct, $magentoProduct);

    /**
     * setDownloadableLinks
     *
     * @api
     * @return $this
     */
    public function setDownloadableLinks($downloads, $magentoProduct, $sortOrder);

    /**
     * setDownloadableSamples
     *
     * @api
     * @return $this
     */
    public function setDownloadableSamples($onesample, $magentoProduct, $sampleSortOrder);

    /**
     * deleteAttribute
     * @param \Magento\Framework\DataObject $object
     * @param \Magento\Eav\Model\Entity\Attribute\AbstractAttribute $attribute
     * @api
     * @return $this
     */

    public function deleteAttribute(\Magento\Framework\DataObject $object, $attribute);
}
