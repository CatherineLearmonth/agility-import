<?php

namespace Agility\Import\Model\Data;

use Agility\Import\Api\Data\AttributeInterface;

class Attribute extends \Magento\Framework\Model\AbstractModel implements AttributeInterface
{
    /*
     * @var string
     */
    protected $name;

    /*
     * @var string
     */
    protected $value;

    /*
     * @var string
     */
    protected $type;

    /**
     *
     * @api
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     *
     * @api
     * @param string $name
     * @return $this
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     *
     * @api
     * @param string $value
     * @return $this
     */
    public function setValue($value)
    {
        $this->value = $value;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     *
     * @api
     * @param string $type
     * @return $this
     */
    public function setType($type)
    {
        $this->type = $type;
        return $this;
    }
}
