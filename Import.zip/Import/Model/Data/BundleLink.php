<?php

namespace Agility\Import\Model\Data;

use Agility\Import\Api\Data\BundleLinkInterface;

class BundleLink extends \Magento\Framework\Api\AbstractExtensibleObject implements BundleLinkInterface
{
	/*
	 * @var string
	 */
	protected $sku;
	/*
	 * @var string
	 */
	protected $quantity;
	/*
	 * @var string
	 */
	protected $canChangeQuantity;
	/*
	 * @var string
	 */
	protected $isDefault;
	/*
	 * @var string
	 */
	protected $price;

	public function __construct()
	{
		return $this;
	}

	/**
	 *
	 * @api
	 * @return $string
	 */
	public function getSku()
	{
		return $this->sku;
	}

	/**
	 *
	 * @api
	 * @param string $sku
	 * @return $this
	 */
	public function setSku($sku)
	{
		$this->sku= $sku;
		return $this;
	}

	/**
	 *
	 * @api
	 * @return $string
	 */
	public function getQuantity()
	{
		return $this->quantity;
	}

	/**
	 *
	 * @api
	 * @param string $quantity
	 * @return $this
	 */
	public function setQuantity($quantity)
	{
		$this->quantity= $quantity;
		return $this;
	}

	/**
	 *
	 * @api
	 * @return $string
	 */
	public function getCanChangeQuantity()
	{
		return $this->canChangeQuantity;
	}

	/**
	 *
	 * @api
	 * @param string $canChangeQuantity
	 * @return $this
	 */
	public function setCanChangeQuantity($canChangeQuantity)
	{
		$this->canChangeQuantity= $canChangeQuantity;
		return $this;
	}

	/**
	 *
	 * @api
	 * @return $string
	 */
	public function getIsDefault()
	{
		return $this->isDefault;
	}

	/**
	 *
	 * @api
	 * @param string $isDefault
	 * @return $this
	 */
	public function setIsDefault($isDefault)
	{
		$this->isDefault= $isDefault;
		return $this;
	}

	/**
	 *
	 * @api
	 * @return $string
	 */
	public function getPrice()
	{
		return $this->price;
	}

	/**
	 *
	 * @api
	 * @param string $price
	 * @return $this
	 */
	public function setPrice($price)
	{
		$this->price= $price;
		return $this;
	}

}
