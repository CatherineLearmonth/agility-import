<?php

namespace Agility\Import\Model\Data;

use Agility\Import\Api\Data\BundleOptionInterface;

class BundleOption extends \Magento\Framework\Api\AbstractExtensibleObject implements BundleOptionInterface
{

    /*
     * @var string
     */
    protected $title;
    /*
     * @var string
     */
    protected $type;
    /*
     * @var string
     */
    protected $priceType;
    /*
     * @var string
     */
    protected $isRequired;
    /*
     * @var string
     */
    protected $shipmentType;

    /**
     *
     * @api
     * @return $string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     *
     * @api
     * @param string $title
     * @return $this
     */
    public function setTitle($title)
    {
        $this->title = $title;
        return $this;
    }

    /**
     *
     * @api
     * @return $string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     *
     * @api
     * @param string $type
     * @return $this
     */
    public function setType($type)
    {
        $this->type= $type;
        return $this;
    }

    /**
     *
     * @api
     * @return $string
     */
    public function getPriceType()
    {
        return $this->priceType;
    }

    /**
     *
     * @api
     * @param string $priceType
     * @return $this
     */
    public function setPriceType($priceType)
    {
        $this->priceType= $priceType;
        return $this;
    }

    /**
     *
     * @api
     * @return $string
     */
    public function getIsRequired()
    {
        return $this->isRequired;
    }

    /**
     *
     * @api
     * @param string $isRequired
     * @return $this
     */
    public function setIsRequired($isRequired)
    {
        $this->isRequired= $isRequired;
        return $this;
    }

    /**
     *
     * @api
     * @return $string
     */
    public function getShipmentType()
    {
        return $this->shipmentType;
    }

    /**
     *
     * @api
     * @param string $shipmentType
     * @return $this
     */
    public function setShipmentType($shipmentType)
    {
        $this->shipmentType= $shipmentType;
        return $this;
    }
}
