<?php

namespace Agility\Import\Model\Data;

use Agility\Import\Api\Data\CategoryInterface as CategoryInterface;

class Category extends \Magento\Framework\Api\AbstractExtensibleObject implements CategoryInterface
{

    /**
     *
     * @api
     * @return string
     */
    public function getName()
    {
        return $this->_get(self::NAME);
    }

    /**
     *
     * @api
     * @param string $name
     * @return $this
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     *
     * @api
     * @return string
     */
    public function getAgilityId()
    {
        return $this->_get(self::AGILITYID);
    }

    /**
     *
     * @api
     * @param string $id
     * @return $this
     */
    public function setAgilityId($agilityId)
    {
        return $this->setData(self::AGILITYID, $agilityId);
    }

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ProductInterface[]
     */
    public function getProduct()
    {
        return $this->_get(self::PRODUCT);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ProductInterface[] $product
     * @return $this
     */
    public function setProduct($product)
    {
        return $this->setData(self::PRODUCT, $product);
    }

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ProductInterface[]
     */
    public function getProducts()
    {
        return $this->_get(self::PRODUCTS);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ProductInterface[] $products
     * @return $this
     */
    public function setProducts(array $products)
    {
        return $this->setData(self::PRODUCTS, $products);
    }

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\CategoryInterface[]
     */
    public function getCategory()
    {
        return $this->_get(self::CATEGORY);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\CategoryInterface[] $category
     * @return $this
     */
    public function setCategory($category)
    {
        return $this->setData(self::CATEGORY, $category);
    }

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\CategoryInterface[]
     */
    public function getCategories()
    {
        return $this->_get(self::CATEGORIES);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\CategoryInterface[] $categories
     * @return $this
     */
    public function setCategories(array $categories)
    {
        return $this->setData(self::CATEGORIES, $categories);
    }
}
