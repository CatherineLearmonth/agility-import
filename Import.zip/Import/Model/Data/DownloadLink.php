<?php

namespace Agility\Import\Model\Data;

use Agility\Import\Api\Data\DownloadLinkInterface;

class DownloadLink extends \Magento\Framework\Model\AbstractModel implements DownloadLinkInterface
{
    /*
     * @var string
     */
    protected $title;

    /*
     * @var string
     */
    protected $sortorder;

    /*
     * @var string
     */
    protected $isshareable;

    /*
     * @var string
     */
    protected $price;

    /*
     * @var string
     */
    protected $numdownloads;

    /*
     * @var string
     */
    protected $imagename;

    /*
     * @var string
     */
    protected $imagepath;

    /*
     * @var string
     */
    protected $linksamplepath;

    /*
     * @var string
     */
    protected $linksamplename;

    /*
     * @var string
     */
    protected $purchasedseparately;

    /**
     *
     * @api
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     *
     * @api
     * @param string $title
     * @return $this
     */
    public function setTitle($title)
    {
        $this->title = $title;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getIsshareable()
    {
        return $this->isshareable;
    }

    /**
     *
     * @api
     * @param string $isshareable
     * @return $this
     */
    public function setIsshareable($isshareable)
    {
        $this->isshareable = $isshareable;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     *
     * @api
     * @param string $price
     * @return $this
     */
    public function setPrice($price)
    {
        $this->price = $price;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getNumdownloads()
    {
        return $this->numdownloads;
    }

    /**
     *
     * @api
     * @param string $numdownloads
     * @return $this
     */
    public function setNumdownloads($numdownloads)
    {
        $this->numdownloads = $numdownloads;
        return $this;
    }
    /**
     *
     * @api
     * @return string
     */
    public function getImagepath()
    {
        return $this->imagepath;
    }

    /**
     *
     * @api
     * @param string $imagepath
     * @return $this
     */
    public function setImagepath($imagepath)
    {
        $this->imagepath = $imagepath;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getLinksamplepath()
    {
        return $this->linksamplepath;
    }

    /**
     *
     * @api
     * @param string $linksamplepath
     * @return $this
     */
    public function setLinksamplepath($linksamplepath)
    {
        $this->linksamplepath = $linksamplepath;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getImagename()
    {
        return $this->imagename;
    }

    /**
     *
     * @api
     * @param string $imagename
     * @return $this
     */
    public function setImagename($imagename)
    {
        $this->imagename = $imagename;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getLinksamplename()
    {
        return $this->linksamplename;
    }

    /**
     *
     * @api
     * @param string $linksamplename
     * @return $this
     */
    public function setLinksamplename($linksamplename)
    {
        $this->linksamplename = $linksamplename;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getPurchasedseparately()
    {
        return $this->purchasedseparately;
    }

    /**
     *
     * @api
     * @param string $purchasedseparately
     * @return $this
     */
    public function setPurchasedseparately($purchasedseparately)
    {
        $this->purchasedseparately = $purchasedseparately;
        return $this;
    }
}
