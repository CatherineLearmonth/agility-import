<?php

namespace Agility\Import\Model\Data;

use Agility\Import\Api\Data\DownloadSampleInterface;

class DownloadSample extends \Magento\Framework\Model\AbstractModel implements DownloadSampleInterface
{
    /*
     * @var string
     */
    protected $title;

    /*
     * @var string
     */
    protected $samplepath;

    /*
     * @var string
     */
    protected $samplename;

    /*
     * @var string
     */
    protected $sortorder;

    /**
     *
     * @api
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     *
     * @api
     * @param string $title
     * @return $this
     */
    public function setTitle($title)
    {
        $this->title = $title;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getSamplepath()
    {
        return $this->samplepath;
    }

    /**
     *
     * @api
     * @param string $samplepath
     * @return $this
     */
    public function setSamplepath($samplepath)
    {
        $this->samplepath = $samplepath;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getSamplename()
    {
        return $this->samplename;
    }

    /**
     *
     * @api
     * @param string $samplename
     * @return $this
     */
    public function setSamplename($samplename)
    {
        $this->samplename = $samplename;
        return $this;
    }
}
