<?php

namespace Agility\Import\Model\Data;

use Agility\Import\Api\Data\ImageInterface;

class Image extends \Magento\Framework\Model\AbstractModel implements ImageInterface
{
    /*
     * @var string
     */
    protected $type;

    /*
     * @var string
     */
    protected $path;

    /*
     * @var string
     */
    protected $label;
    /*
     * @var string
     */
    protected $filetype;

    public function __construct()
    {
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     *
     * @api
     * @param string $type
     * @return $this
     */
    public function setType($type)
    {
        $this->type= $type;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getPath()
    {
        return $this->path;
    }

    /**
     *
     * @api
     * @param string $path
     * @return $this
     */
    public function setPath($path)
    {
        $this->path = $path;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getLabel()
    {
        return $this->label;
    }

    /**
     *
     * @api
     * @param string $label
     * @return $this
     */
    public function setLabel($label)
    {
        $this->label = $label;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getFiletype()
    {
        return $this->filetype;
    }

    /**
     *
     * @api
     * @param string $filetype
     * @return $this
     */
    public function setFiletype($filetype)
    {
        $this->filetype = $filetype;
        return $this;
    }
}
