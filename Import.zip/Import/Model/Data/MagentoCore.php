<?php

namespace Agility\Import\Model\Data;

use Agility\Import\Api\Data\MagentoCoreInterface;

class MagentoCore extends \Magento\Framework\Model\AbstractModel implements MagentoCoreInterface
{

    /*
     * @var string
     */
    protected $attributesetname;

    /*
     * @var string
     */
    protected $instock;

    /*
     * @var string
     */
    protected $name;

    /*
     * @var string
     */
    protected $sku;

    /*
    * @var string
    */
    protected $status;

    /*
     * @var string
     */
    protected $price;

    /*
     * @var string
     */
    protected $quantity;

    /*
     * @var string
     */
    protected $weight;

    /*
     * @var string
     */
    protected $type;

    /**
     *
     * @api
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     *
     * @api
     * @param string $name
     * @return $this
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getSku()
    {
        return $this->sku;
    }

    /**
     *
     * @api
     * @param string $sku
     * @return $this
     */
    public function setSku($sku)
    {
        $this->sku = $sku;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     *
     * @api
     * @param string $price
     * @return $this
     */
    public function setPrice($price)
    {
        $this->price = $price;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getWeight()
    {
        return $this->weight;
    }

    /**
     *
     * @api
     * @param string $weight
     * @return $this
     */
    public function setWeight($weight)
    {
        $this->weight = $weight;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getAttributesetname()
    {
        return $this->attributesetname;
    }

    /**
     *
     * @api
     * @param string $attributesetname
     * @return $this
     */
    public function setAttributesetname($attributesetname)
    {
        $this->attributesetname = $attributesetname;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getInstock()
    {
        return $this->instock;
    }

    /**
     *
     * @api
     * @param string $instock
     * @return $this
     */
    public function setInstock($instock)
    {
        $this->instock = $instock;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getQuantity()
    {
        return $this->quantity;
    }

    /**
     *
     * @api
     * @param string $quantity
     * @return $this
     */
    public function setQuantity($quantity)
    {
        $this->quantity = $quantity;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     *
     * @api
     * @param string $status
     * @return $this
     */
    public function setStatus($status)
    {
        $this->status = $status;
        return $this;
    }

    /**
     *
     * @api
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     *
     * @api
     * @param string $type
     * @return $this
     */
    public function setType($type)
    {
        $this->type = $type;
        return $this;
    }
}
