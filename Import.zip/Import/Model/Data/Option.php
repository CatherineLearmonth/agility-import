<?php

namespace Agility\Import\Model\Data;

use Agility\Import\Api\Data\OptionInterface;

class Option extends \Magento\Framework\Api\AbstractExtensibleObject implements OptionInterface
{

    /**
     *
     * @api
     * @return string
     */
    public function getName()
    {
        return $this->_get(self::NAME);
    }

    /**
     *
     * @api
     * @param string $name
     * @return $this
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     *
     * @api
     * @return string
     */
    public function getAgilityId()
    {
        return $this->_get(self::AGILITYID);
    }

    /**
     *
     * @api
     * @param string $agilityId
     * @return $this
     */
    public function setAgilityId($agilityId)
    {
        return $this->setData(self::AGILITYID, $agilityId);
    }

    /**
     *
     * @api
     * @return string
     */
    public function getParentAgilityId()
    {
        return $this->_get(self::PARENTAGILITYID);
    }

    /**
     *
     * @api
     * @param string parentAgilityId
     * @return $this
     */
    public function setParentAgilityId($parentAgilityId)
    {
        return $this->setData(self::PARENTAGILITYID, $parentAgilityId);
    }

    /**
     *
     * @api
     * @return string
     */
    public function getSalesCategory()
    {
        return $this->_get(self::SALESCATEGORY);
    }

    /**
     *
     * @api
     * @param string $salesCategory
     * @return $this
     */
    public function setSalesCategory($salesCategory)
    {
        return $this->setData(self::SALESCATEGORY, $salesCategory);
    }

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\MagentoCoreInterface
     */
    public function getMagentoCore()
    {
        return $this->_get(self::MAGENTOCORE);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\MagentoCoreInterface $magentoCore
     * @return $this
     */
    public function setMagentoCore($magentoCore)
    {
        return $this->setData(self::MAGENTOCORE, $magentoCore);
    }

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\AttributeInterface
     */
    public function getAttribute()
    {
        return $this->_get(self::ATTRIBUTE);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\AttributeInterface $attribute
     * @return $this
     */
    public function setAttribute($attribute)
    {
        return $this->setData(self::ATTRIBUTE, $attribute);
    }

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\AttributeInterface[]
     */
    public function getAttributes()
    {
        return $this->_get(self::ATTRIBUTES);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\AttributeInterface[] $attributes
     * @return $this
     */
    public function setAttributes(array $attributes)
    {
        return $this->setData(self::ATTRIBUTES, $attributes);
    }

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ImageInterface
     */
    public function getImage()
    {
        return $this->_get(self::IMAGE);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ImageInterface $image
     * @return $this
     */
    public function setImage($image)
    {
        return $this->setData(self::IMAGE, $image);
    }

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ImageInterface[]
     */
    public function getImages()
    {
        return $this->_get(self::IMAGES);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ImageInterface[] $images
     * @return $this
     */
    public function setImages(array $images)
    {
        return $this->setData(self::IMAGES, $images);
    }
}
