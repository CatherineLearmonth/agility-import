<?php

namespace Agility\Import\Model\Data;

use Agility\Import\Api\Data\RelatedSkuInterface;

class RelatedSku extends \Magento\Framework\Api\AbstractExtensibleObject implements RelatedSkuInterface
{

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\AttributeInterface
     */
    public function getAttribute()
    {
        return $this->_get(self::ATTRIBUTE);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\AttributeInterface $attribute
     * @return $this
     */
    public function setAttribute($attribute)
    {
        return $this->setData(self::ATTRIBUTE, $attribute);
    }

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\AttributeInterface[]
     */
    public function getAttributes()
    {
        return $this->_get(self::ATTRIBUTES);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\AttributeInterface[] $attributes
     * @return $this
     */
    public function setAttributes(array $attributes)
    {
        return $this->setData(self::ATTRIBUTES, $attributes);
    }
}
