<?php

namespace Agility\Import\Model;

use Agility\Import\Api\Data\ExportInterface as ExportInterface;

class Export extends \Magento\Framework\Api\AbstractExtensibleObject implements ExportInterface
{

    public function getCategory()
    {
        return $this->_get(self::CATEGORY);
    }

    public function setCategory($category)
    {
        return $this->setData(self::CATEGORY, $category);
    }

    /**
     * getCategories
     *
     * @return Agility\Import\Api\Data\CategoryInterface[]
     */
    public function getCategories()
    {
        return $this->_get(self::CATEGORIES);
    }

    /**
     * setCategories
     *
     * @param Agility\Import\Api\Data\CategoryInterface[] $categories
     * @return $this
     */
    public function setCategories(array $categories)
    {
        return $this->setData(self::CATEGORIES, $categories);
    }

    public function getProduct()
    {
        return $this->_get(self::PRODUCT);
    }

    public function setProduct($product)
    {
        return $this->setData(self::PRODUCT, $product);
    }

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\ProductInterface[]
     */
    public function getProducts()
    {
        return $this->_get(self::PRODUCTS);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\ProductInterface[] $products
     * @return $this
     */
    public function setProducts(array $products)
    {
        return $this->setData(self::PRODUCTS, $products);
    }

    public function getOption()
    {
        return $this->_get(self::OPTION);
    }

    public function setOption($option)
    {
        return $this->setData(self::OPTION, $option);
    }

    /**
     *
     * @api
     * @return Agility\Import\Api\Data\OptionInterface[]
     */
    public function getOptions()
    {
        return $this->_get(self::OPTIONS);
    }

    /**
     *
     * @api
     * @param Agility\Import\Api\Data\OptionInterface[] $options
     * @return $this
     */
    public function setOptions(array $options)
    {
        return $this->setData(self::OPTIONS, $options);
    }
}
