<?php

namespace Agility\Import\Model;

use \Agility\Import\Api\ImportInterface;
use Magento\Framework\ObjectManagerInterface;
use \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;
use Magento\Quote\Api\Data as QuoteApi;
use Magento\ConfigurableProduct\Helper\Product\Options\Factory;
use Magento\Store\Api\StoreResolverInterface;
use Magento\Catalog\Model\Category;

/**
 * Import Class Comment
 *
 * @category Class
 * @package  Import
 * @author   C Learmonth
 *
 */

class Import implements ImportInterface
{
    const RESOURCE_PATH = '/V1/categories';
    const SERVICE_NAME = 'catalogCategoryRepositoryV1';
    /**
     * @var QuoteApi\ProductOptionExtensionFactory
     */
    protected $productOptionExtensionFactory;
    /**
     * @var ObjectManagerInterface
     */
    protected $objectManager;

    /**
     * @var \Magento\Catalog\Api\Data\ProductExtensionFactory
     */
    protected $productExtensionFactory;

    /**
     * @var \Magento\Framework\Api\SearchCriteriaInterface
     */
    protected $searchCriteria;

    /**
     * @var \Magento\Framework\Api\FilterBuilder
     */
    protected $filterBuilder;

    /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * EAV attribute object
     *
     * @var Magento\Catalog\Model\ResourceModel\Eav\Attribute
     */
    protected $attributeObj;

    /**
     * @var \Magento\Catalog\Api\ProductAttributeRepositoryInterface
     */
    protected $attributeRepository;

    /**
     * @var \Magento\Eav\Api\AttributeOptionManagementInterface
     */

    protected $attributeOptionManagement;

    protected $option;

    protected $attributeOptionLabel;

    protected $customAttributeFactory;

    /**
     * @var Factory
     */
    protected $optionsFactory;

    /** var  \Magento\Catalog\Api\ProductAttributeMediaGalleryManagementInterface */
    protected $mgManagement;

    /**
     * @var StoreResolverInterface
     */
    protected $storeResolver;

    protected $productRepository;

    protected $categoryRepository;

    protected $attributeSet;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Attribute
     */
    private $attributeResource;

    public function __construct(
        ObjectManagerInterface $objectManager,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Catalog\Api\Data\ProductExtensionFactory $productExtensionFactory,
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria,
        \Magento\Framework\Api\FilterBuilder $filterBuilder,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Catalog\Model\ResourceModel\Eav\Attribute $attributeObj,
        \Magento\Eav\Api\AttributeRepositoryInterface $attributeRepository,
        \Magento\Eav\Api\AttributeOptionManagementInterface $attributeOptionManagement,
        \Magento\Eav\Api\Data\AttributeOptionLabelInterface $attributeOptionLabel,
        \Magento\Eav\Model\Entity\Attribute\Option $option,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        Factory $optionsFactory,
        \Magento\Catalog\Api\ProductAttributeMediaGalleryManagementInterface $mgManagement,
        StoreResolverInterface $storeResolver,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository,
        \Psr\Log\LoggerInterface $logger,
        //log injection
        \Magento\Eav\Api\AttributeSetRepositoryInterface $attributeSet
    ) {
                $this->objectManager = $objectManager;
                $this->categoryFactory = $categoryFactory;
                $this->categoryCollectionFactory = $categoryCollectionFactory;
                $this->productCollectionFactory = $productCollectionFactory;
                $this->productExtensionFactory = $productExtensionFactory;
                $this->searchCriteria = $searchCriteria;
                $this->filterBuilder = $filterBuilder;
                $this->searchCriteriaBuilder = $searchCriteriaBuilder;
                $this->attributeObj = $attributeObj;
                $this->attributeRepository = $attributeRepository;
                $this->attributeOptionManagement = $attributeOptionManagement;
                $this->option = $option;
                $this->attributeOptionLabel = $attributeOptionLabel;
                $this->customAttributeFactory = $customAttributeFactory;
                $this->optionsFactory = $optionsFactory;
                $this->mgManagement = $mgManagement;
                $this->storeResolver = $storeResolver;
                $this->productLoader = $productRepository;
                $this->categoryLoader = $categoryRepository;
                $this->logger = $logger;
                $this->attributeSet = $attributeSet;
    }

    /**
     * Create process
     *
     * This is called by both the full exporter and incremental updater to create and update categories,
     * products and options. It first checks the attributes on each product and option
     * and creates new attributes if they don't already exist in Magento.
     * After all the products and options have been created, a check is done for product relations.
     * This needs to be done at the end of processing as otherwise a product may be related
     * to a product that has not yet been added, and this relation would be missed.
     *
     * @param Agility\Import\Api\Data\ExportInterface $agilityExport
     */

    public function create($agilityExport)
    {
        $category = $agilityExport->getCategory();
        if (!$category) {
            $categories = $agilityExport->getCategories();
            //more than one category on the export
            if ($categories) {
                foreach ($categories as $oneCategory) {
                    //add all missing attributes to eav_attribute table first
                    $this->processAttributes($oneCategory);
                    $id = $this->createCategory($oneCategory, null);
                    $agilityProduct= $oneCategory->getProduct();
                    //create all links to related products
                    if (!$agilityProduct) {
                        $agilityProducts = $oneCategory->getProducts();
                        if ($agilityProducts) {
                            foreach ($agilityProducts as $oneProduct) {
                                $result = $this->processRelations($oneProduct);
                            }
                        }
                    } else {
                        $result = $this->processRelations($agilityProduct);
                    }
                }
                //need to check for products at the same level as the categories
                $this->checkForProductsAndOptions($agilityExport);
                $this->checkForRelations($agilityExport);                
            } else {
            	//no category or categories so check for products
                $this->checkForProductsAndOptions($agilityExport);
                $this->checkForRelations($agilityExport);
            }
        } else {
        	//one category
            $this->processAttributes($category);
            $id = $this->createCategory($category, null);
            //check for products at same level as category
            $this->checkForProductsAndOptions($agilityExport);
            $this->checkForRelations($agilityExport);
            //products within the category
            $agilityProduct= $category->getProduct();
            //process relations for each product in a category
            if (!$agilityProduct) {
                $agilityProducts = $category->getProducts();
                if ($agilityProducts) {
                    foreach ($agilityProducts as $oneProduct) {
                        $result = $this->processRelations($oneProduct);
                    }
                }
            } else {
            	//one product in a category
                $result = $this->processRelations($agilityProduct);
            }
        }

    }

    /**
     * Process attributes - write attributes to the EAV table
     * Check the attributes on the products and options to see if they exist in
     * Magento, if they don't, add them to the eav_attribute table.
     *
     * @param  Agility\Import\Api\Data\CategoryInterface $category
     */

    public function processAttributes($category)
    {
        //get category products, then attributes on the product
        $agilityProduct= $category->getProduct();

        if (!$agilityProduct) {
            $agilityProducts = $category->getProducts();
            if ($agilityProducts) {
                foreach ($agilityProducts as $oneProduct) {
                    $attribute = $oneProduct->getAttribute();
                    if (!$attribute) {
                        $attributes = $oneProduct->getAttributes();
                        foreach ($attributes as $oneAttribute) {
                            $this->checkAgilityAttributes($oneAttribute, $oneProduct);
                        }
                    } else {
                        $this->checkAgilityAttributes($attribute, $oneProduct);
                    }
                    //get variant attributes
                    $option = $oneProduct->getOption();
                    if (!$option) {
                        $options = $oneProduct->getOptions();
                        if ($options) {
                            foreach ($options as $oneOption) {
                                $attribute = $oneOption->getAttribute();
                                $this->checkAgilityAttributes($attribute, $oneOption);
                            }
                        }
                    } else { //one variant
                        $attribute = $option->getAttribute();
                        $this->checkAgilityAttributes($attribute, $option);
                    }
                }
            }
        } else {  //one product
            $attribute = $agilityProduct->getAttribute();
            if (!$attribute) {
                $attributes = $agilityProduct->getAttributes();
                foreach ($attributes as $oneAttribute) {
                    $this->checkEavAttribute($oneAttribute, $agilityProduct);
                }
            } else {
                $this->checkEavAttribute($attribute, $agilityProduct);
            }

            $option = $agilityProduct->getOption();

            if (!$option) {
                $options = $agilityProduct->getOptions();
                if ($options) {
                    foreach ($options as $oneOption) {
                        $attribute = $oneOption->getAttribute();
                        $this->checkAgilityAttributes($attribute, $oneOption);
                    }
                }
            } else { //one variant
                $attribute = $option->getAttribute();
                $this->checkAgilityAttributes($attribute, $option);
            }
        }

    }

    /**
     * Check if the agility object has one or more attributes on it
     *
     * @param Agility\Import\Api\Data\AttributeInterface $attribute
     * @param Agility\Import\Api\Data\ProductInterface $agilityObj
     *
     */
    public function checkAgilityAttributes($attribute, $agilityObj)
    {
        if (!$attribute) {
            $attributes = $agilityObj->getAttributes();
            if ($attributes != null) {
                foreach ($attributes as $oneAttribute) {
                    $this->checkEavAttribute($oneAttribute, $agilityObj);
                }
            }
        } else {
            $this->checkEavAttribute($attribute, $agilityObj);
        }
    }

    /**
     * Check eav attribute exists and create if not process
     *
     * @param Agility\Import\Api\Data\AttributeInterface $oneAttribute
     * @param Agility\Import\Api\Data\ProductInterface  $agilityObj
     */

    public function checkEavAttribute($attribute, $agilityObj)
    {
        $agilityAttrName = $attribute->getName();

        if ($agilityAttrName!= null) {
            $cleanAttrName = $this->convertText($agilityAttrName);
            $agilityAttrValue = $attribute->getValue();
            //get all existing magento product eav attributes
            $existingAttrArray[] = $this->getMagentoAttribs();
            //attribute does not exists
            if (!in_array($cleanAttrName, $existingAttrArray[0])) {
                //create an eav_attribute - need to pass in the type to build it
                $agilityAttrType = $attribute->getType();
                $this->createEavAttribute($agilityAttrName, $agilityAttrType, $agilityAttrValue, $agilityObj);
            } else {
                //attribute already exists - see if we need to add new options
                $arrayValues = $this->checkArray($agilityAttrValue);
                if ($arrayValues) {
                    foreach ($arrayValues as $oneValue) {
                        $this->checkForOptions($cleanAttrName, $oneValue);
                    }
                } else {
                    $this->checkForOptions($cleanAttrName, $agilityAttrValue);
                }
            }
        }

    }

    /**
     * Delete process
     * This method is called by the incremental updater only to delete
     * categories/products and options.
     *
     * @param Agility\Import\Api\Data\ExportInterface $agilityExport
     */

    public function delete($agilityExport)
    {
        $category = $agilityExport->getCategory();
        if (!$category) {
            $categories = $agilityExport->getCategories();

            if ($categories) {
                foreach ($categories as $oneCategory) {
                    $this->deleteCategory($oneCategory);
                }
            }
        } else {
            $this->deleteCategory($category);
        }

        $agilityProduct= $agilityExport->getProduct();
        if (!$agilityProduct) {
            $agilityProducts = $agilityExport->getProducts();

            if ($agilityProducts) {
                foreach ($agilityProducts as $oneProduct) {
                    $this->deleteProduct($oneProduct);
                }
            }
        } else {
            $result = $this->deleteProduct($agilityProduct);
        }

        $option = $agilityExport->getOption();
        if (!$option) {
            $options = $agilityExport->getOptions();

            if ($options) {
                foreach ($options as $oneOption) {
                    $this->deleteProduct($oneOption);
                }
            }
        } else {
            $this->deleteProduct($option);
        }

    }

    /**
     * Move process - only required for incremental product or variant moves
     * Note that category moves are handled within the Create process code
     *
     * @param Agility\Import\Api\Data\ExportInterface $agilityExport
     */

    public function move($agilityExport)
    {
        //as incremental should just be one product or variant at a time
        //note that category move is done within the update code
        $option = false;

        $agilityProduct= $agilityExport->getProduct();
        $type = 'product';
        $productArray = [];

        if (!$agilityProduct) {
            $agilityProduct = $agilityExport->getOption();
            if ($agilityProduct) {
                $optionIds = [];
                $options = [];
                $option = true;
            }
        }

        if ($agilityProduct) {
            $agilityId = $agilityProduct->getAgilityId();
            $agilityObj = $this->getAgilityObjectId($agilityId);
            $productId = $this->getObjectById($agilityObj, $type);

            if ($productId) {
                $magentoProduct = $this->productLoader->getById($productId);
                //moving an option - update old and new parent configurations, update category
                if ($option) {
                    //need new parent - update it with the option values
                    $this->addParentOptions($agilityId, $productId, $agilityProduct, false, $magentoProduct);
                    $this->removeParentOptions($type, $agilityProduct, $productId);

                    //get new category that the option belongs under
                    $newCategoryId = $this->getParentId($agilityId, 'category', true); //grandparent id
                    $parentagilityId = $agilityProduct->getParentAgilityId(); //this will be a product
                    $oldParentId = $this->getParentId($parentagilityId, 'category', false); //need parent of the product
                    $productArray[] = $productId; //single product move
                } else {
                    //moving a product
                    $newCategoryId = $this->getParentId($agilityId, 'category', false);
                    $parentagilityId = $agilityProduct->getParentAgilityId();
                    $parentObjId = $this->getAgilityObjectId($parentagilityId);
                    $type = 'category';
                    $oldParentId = $this->getObjectById($parentObjId, $type);
                    //need to also get any product options and update their category id too
                    $optionsFactory = $this->objectManager->create(Factory::class);
                    $extensionConfigurableAttributes = $magentoProduct->getExtensionAttributes();
                    $existingOptionIds = $extensionConfigurableAttributes->getConfigurableProductLinks();
                    if ($existingOptionIds) {
                        //product with variants move
                        $productArray = $existingOptionIds;
                        array_push($productArray, $productId);
                    } else {
                        $productArray[] = $productId; //single product move
                    }
                }
                if ($oldParentId) {
                    //if it finds previous parent - can't reset the custom attribute so need to update the table!!
                    if ($oldParentId != $newCategoryId) {
                        foreach ($productArray as $productId) {
                            $this->updateProductCategory($oldParentId, $newCategoryId, $productId);
                        }
                    }
                } else {
                    $magentoProduct->setCustomAttribute('category_ids', $newParentId);
                    try {
                        $id = $this->productLoader->save($magentoProduct);
                    } catch (\Exception $e) {
                        $this->logger->info("AgilityImport:move product save failed message is {$e->getMessage()}");
                    }
                }
            } else {
                $this->logger->info("AgilityImport:move failed to find agility object {$agilityObj}");
            }
        }

    }

    /**
     * Link process - only required for incremental product or variant links
     * Note that it is not possible for a Magento category to exist in more than
     * one place and an informational message is output for this scenario.
     *
     * @param Agility\Import\Api\Data\ExportInterface  $agilityExport
     */

    public function link($agilityExport)
    {
        //as incremental should just be one product or variant at a time
        $option = false;

        $agilityCategory = $agilityExport->getCategory();
        if ($agilityCategory) {
            $this->logger->info("AgilityImport:link it is not possible to link a category in the Magento structure");
        }

        $agilityProduct= $agilityExport->getProduct();
        if (!$agilityProduct) {
            $agilityProduct = $agilityExport->getOption();
            if ($agilityProduct) {
                $option = true;
            }
        }

        if ($agilityProduct) {
            $agilityId = $agilityProduct->getAgilityId();
            $agilityObj = $this->getAgilityObjectId($agilityId);
            $type = 'product';
            $productId = $this->getObjectById($agilityObj, $type);

            if ($productId) {
                $magentoProduct = $this->productLoader->getById($productId);
                if ($option) {
                    //grandparent id should be category for an option
                    $newParentId = $this->getParentId($agilityId, 'category', true);
                    $this->addParentOptions($agilityId, $productId, $agilityProduct, true, $magentoProduct);
                } else {
                    //get the new category the product belongs to
                    $parentagilityId = $agilityProduct->getParentAgilityId();
                    $agilityObj = $this->getAgilityObjectId($parentagilityId);
                    $type = 'category';
                    $newParentId = $this->getObjectById($agilityObj, $type);
                }
                $this->insertProductCategory($newParentId, $productId);
            } else {
                $this->logger->info("AgilityImport:link failed to find agility object {$agilityObj}");
            }
        }
    }

    /**
     * Unlink process - only required for incremental product or variant unlinks
     *
     * @param Agility\Import\Api\Data\ExportInterface $agilityExport
     */

    public function unlink($agilityExport)
    {
        //as incremental should just be one product or variant at a time
        $option = false;

        $agilityProduct= $agilityExport->getProduct();
        if (!$agilityProduct) {
            $agilityProduct = $agilityExport->getOption();
            if ($agilityProduct) {
                $option = true;
            }
        }

        if ($agilityProduct) {
            $agilityId = $agilityProduct->getAgilityId();
            $agilityObj = $this->getAgilityObjectId($agilityId);
            $type = 'product';
            $productId = $this->getObjectById($agilityObj, $type);
            if ($productId) {
                $magentoProduct = $this->productLoader->getById($productId);
                if ($option) {
                    $parentagilityId = $agilityProduct->getParentAgilityId();
                    $removeParentId = $this->getParentId($parentagilityId, 'category', false);
                    $this->removeParentOptions($type, $agilityProduct, $productId);
                } else {
                    $parentagilityId = $agilityProduct->getParentAgilityId();
                    $agilityObj = $this->getAgilityObjectId($parentagilityId);
                    $type = 'category';
                    $removeParentId = $this->getObjectById($agilityObj, $type);
                }
                $this->deleteProductCategory($removeParentId, $productId);
            } else {
                $this->logger->info("AgilityImport:unlink failed to find agility object {$agilityObj}");
            }
        }
    }

    /**
     * Create category process
     * This process creates and updates categories in Magento
     * It checks if the category already exists in Magento and creates a
     * category if it does not exist, otherwise updates the existing category.
     *
     * @param Agility\Import\Api\Data\CategoryInterface $category
     * @param \Magento\Catalog\Api\Data\CategoryInterface $parentObj $parentObj
     * @return string
     */
    public function createCategory($category, $parentObj)
    {
        $categoryObj = $this->objectManager->create('\Magento\Catalog\Api\Data\CategoryInterface');
        //check if category exists before creating it
        $agilityId = $category->getAgilityId();
        $agilityObj = $this->getAgilityObjectId($agilityId);
        $catName = $category->getName();
        $id = null;

        $type = 'category';
        $id = $this->getObjectById($agilityObj, $type);

        if (!$id) { //try getting by name instead of agility id
            $id = $this->getCategoryIdfromName($catName, $parentObj);
        }

        //create a new category as no existing one found
        if (!$id) {
            $categoryUpd = $this->getCategoryData($category, $categoryObj);
            try {
                $magCategory = $this->categoryLoader->save($categoryUpd);
                $id = $magCategory->getId();
            } catch (\Exception $e) {
                $this->logger->info("AgilityImport:createCategory category save failed message is {$e->getMessage()}");
            }
        } else {
            $result = $this->updateCategory($category, $id);
        }

        //get category products
        $agilityProduct= $category->getProduct();

        //create all the products on the extract
        if (!$agilityProduct) {
            $agilityProducts = $category->getProducts();
            if ($agilityProducts) {
                foreach ($agilityProducts as $oneProduct) {
                    $result = $this->createProduct($oneProduct, $id);
                }
            }
        } else {
            $result = $this->createProduct($agilityProduct, $id);
        }

        //have we got any nested categories ?

        $categories = $category->getCategories();

        if ($categories) {
            foreach ($categories as $oneCategory) {
                //add all missing attributes to eav_attribute table first
                $this->processAttributes($oneCategory);
                $result = $this->createCategory($oneCategory, $parentObj);
            }
        } else { //one category
            $subcat = $category->getCategory();
            if ($subcat != null) {
                $this->processAttributes($subcat);
                $result = $this->createCategory($subcat, $parentObj);
            }
        }

        return $id;
    }

    /**
     * Get category data process - this sets all the values on a newly created
     * category and returns the category object.
     *
     * @param Agility\Import\Api\Data\CategoryInterface $category
     * @param \Magento\Catalog\Api\Data\CategoryInterface $categoryObj
     * @return \Magento\Catalog\Api\Data\CategoryInterface
     */

    protected function getCategoryData($category, $categoryObj)
    {
        $categoryObj->setStoreId(0);

        $name = $category->getName();
        $categoryObj->setName($name);

        $agilityId = $category->getAgilityId();
        $agilityObj = $this->getAgilityObjectId($agilityId);
        $parentId = 1; //default parentid

        $categoryObj->setCustomAttribute('agilityid', $agilityObj);

        $parentId = $this->getParentId($agilityId, 'category', false);

        if ($parentId) {
            $categoryObj->setParentId($parentId);
        }

        $categoryObj->setIsActive(true);
        $categoryObj->setIncludeInMenu(true);

        return $categoryObj;
    }

    /**
     * Delete category process
     * This process finds the category and deletes it by id.
     * It also removes the id from the url_rewrite table, as if the category is
     * recreated, it will fail if Magento finds an existing entry for the
     * category on this table.
     *
     * @param  Agility\Import\Api\Data\CategoryInterface $category
     */

    protected function deleteCategory($category)
    {
        $agilityId = $category->getAgilityId();
        $agilityObj = $this->getAgilityObjectId($agilityId);
        $type = 'category';
        $id = $this->getObjectById($agilityObj, $type);

        if ($id) {
            try {
                $categoryObj = $this->categoryLoader->get($id);
                $object = $categoryObj->getResource();
                $connection = $object->getConnection();
                $this->categoryLoader->deleteByIdentifier($id);
                if ($connection) {
                    $this->deleteUrlRewrite($connection, $id);
                }
                return;
            } catch (\Exception $e) {
                $this->logger->info("AgilityImport:deleteCategory failed for {$id} with message {$e->getMessage()} ");
                return;
            }
        } else {
            $this->logger->info("AgilityImport:deleteCategory no category found to delete for {$agilityId}");
        }

    }

    /**
     * Delete product process
     * This process finds the product and deletes it by id, using the sku.
     * It also removes the id from the url_rewrite table, as if the product is
     * recreated, it will fail if Magento finds an existing entry for the
     * product on this table.
     *
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     */

    protected function deleteProduct($agilityProduct)
    {
        $result = null;

        $agilityId = $agilityProduct->getAgilityId();
        $agilityObj = $this->getAgilityObjectId($agilityId);
        $type = 'product';
        $id = $this->getObjectById($agilityObj, $type);

        if ($id) {
            $magentoProduct = $this->productLoader->getById($id);
            if ($magentoProduct) {
                $sku = $magentoProduct->getSku();
                if ($sku) {
                    try {
                        $object = $magentoProduct->getResource();
                        $connection = $object->getConnection();
                        $result = $this->productLoader->deleteById($sku);
                        if ($connection) {
                            $this->deleteUrlRewrite($connection, $id);
                        }
                    } catch (\Exception $e) {
                        $this->logger->info("AgilityImport:deleteProduct failed for 
                            {$sku} with message {$e->getMessage()}");
                        return false;
                    }
                }
            }
        } else {
            $this->logger->info("AgilityImport:deleteProduct no sku found
            		to delete with id {$agilityId}");
            return false;
        }

        return $result;
    }

    /**
     * Update category process
     * This process update the attributes on an existing category
     * If the category has been moved, this method will update the parent path
     *
     * @param Agility\Import\Api\Data\CategoryInterface $category
     * @param string $id
     */

    protected function updateCategory($category, $id)
    {

        $magCategory = $this->objectManager->create('\Magento\Catalog\Model\CategoryManagement');

        $catAgilityid = $category->getAgilityId(); //find on idpath value
        $agilityObj = $this->getAgilityObjectId($catAgilityid);
        $name = $category->getName(); //get Agility name
        $urlKey = strtolower($name);

        if ($catAgilityid) {
            $categoryObj = $this->categoryLoader->get($id);

            if ($name) {
                $categoryObj->setData('name', $name);
                $categoryObj->setData('url_key', $urlKey);
                $categoryObj->setStoreId(0);
                $categoryObj->getResource()->saveAttribute($categoryObj, 'name');
                $categoryObj->getResource()->saveAttribute($categoryObj, 'url_key');
            }

            $existingagilityid = $categoryObj->getCustomAttribute('agilityid');
            $categoryObj->setData('agilityid', $agilityObj);
            $categoryObj->getResource()->saveAttribute($categoryObj, 'agilityid');
            //update parent path for moves
            $existingParentId = $categoryObj->getParentId();
            $parentId = $this->getParentId($catAgilityid, 'category', false);

            if ($parentId > 1) {
                if ($parentId != $existingParentId) {
                    $magCategory->move($id, $parentId, null);
                }
            }
        }
    }

    /**
     * Get category id from name process
     * This process finds the category name, within its parent path and returns
     * the category id.
     *
     * @param string $catName
     * @param \Magento\Catalog\Api\Data\CategoryInterface $parentObj
     * @return string
     */

    protected function getCategoryIdfromName($catName, $parentObj)
    {
        $categoryId = null;
        $collection = $this->categoryCollectionFactory->create();

        if ($parentObj) {
            //get the parent path and add this to filter
            $parentPath = $parentObj->getPath();
            $collection->addPathFilter($parentPath);
        }

        if ($catName) {
            $collection->addAttributeToFilter('name', $catName);
            $categoryId = $collection->getFirstItem()->getId();
        }

        return $categoryId;
    }

    /**
     * Get object by Agility Id process
     * This method creates either a product or category collection, depending
     * on the type field passed in. Then it filters on the 'agilityid'
     * attribute to see if it can find an object that matches that value.
     * The collection gets all items, and loops through them to check that the
     * agility id does indeed match the object id.
     * The method returns the magento id found for either the product or
     * category.
     *
     * @param string $objectId
     * @param string $type
     * @return string
     */

    protected function getObjectById($objectId, $type)
    {

        if ($type == 'product') {
            $collection = $this->productCollectionFactory->create();
            $table = 'catalog_product_entity_varchar';
        } else {
            $collection = $this->categoryCollectionFactory->create();
            $table = 'catalog_category_entity_varchar';
        }

        $collection->addAttributeToSelect('*');
        $collection->addAttributeToFilter('agilityid', $objectId);
        $magentoObjId = null;

        try {
            $ids = $collection->getItems();
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:getObjectById failed for {$objectId} with message {$e->getMessage()}");
            return $magentoObjId;
        }

        foreach ($ids as $id) {
            $collAgilityId = $id->getData('agilityid');
            if ($collAgilityId == $objectId) {
                $magentoObjId = $id->getId();
            }
        }

        return $magentoObjId;
    }

    /**
     * Create/Update product process
     * This method searches for an existing product that matches the agility
     * object id. If it does not find one, then it creates a new product,
     * otherwise it updates the existing product.
     *
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @param string $catIdString
     */
    protected function createProduct($agilityProduct, $catIdString)
    {

        /** @var \Magento\Catalog\Api\Data\ProductInterface $product */
        $magentoProduct = $this->objectManager->create('\Magento\Catalog\Api\Data\ProductInterface');

        $agilityId = $agilityProduct->getAgilityId();
        $agilityObj = $this->getAgilityObjectId($agilityId);
        $type = 'product';
        $id = $this->getObjectById($agilityObj, $type);

        if (!$id) {    //no existing id found so create a new product
            $this->getProductData($agilityProduct, $magentoProduct, $catIdString);
        } else { //update the existing product
            $magentoProduct = $this->productLoader->getById($id);

            if ($magentoProduct) { //finds existing product
                $this->updateProductValues($agilityProduct, $magentoProduct, null);
            }
        }
    }

    /**
     * Create/Update option process
     * This method searches for an existing product option that matches the
     * agility object id.
     * If it does not find one, then it creates a new product option,
     * otherwise it updates the existing product option.
     *
     * @param Agility\Import\Api\Data\OptionInterface $option
     * @return string
     */
    protected function checkOption($option)
    {
        /** @var \Magento\Catalog\Api\Data\ProductInterface $product */
        $magentoProduct = $this->objectManager->create('\Magento\Catalog\Api\Data\ProductInterface');
        $agilityId = $option->getAgilityId();
        $agilityObj = $this->getAgilityObjectId($agilityId);
        $type = 'product';
        $id = $this->getObjectById($agilityObj, $type);

        if (!$id) {    //no existing id found so create a new option
            $id = $this->createVariant($option);
        } else { //update the existing product
            $magentoProduct = $this->productLoader->getById($id);
            if ($magentoProduct) { //finds existing product
                $id = $this->updateOptionValues($option, $magentoProduct);
            }
        }

        return $id;
    }

    /**
     * Get product data process
     * This method sets the product data on the magento product
     * It checks if the product is downloadable and sets that accordingly.
     * Then it sets the core Magento values, based on the magento core passed in.
     * Then it sets any general attributes on the product
     * Then it process images
     * Then it checks for options on the product and adds those options to a
     * configuable product.
     *
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @param String $catIdString
     */

    protected function getProductData($agilityProduct, $magentoProduct, $catIdString)
    {

        $magentoProduct = $this->setDownloadable($agilityProduct, $magentoProduct);

        $magentoProduct = $this->setMagentoValues($agilityProduct, $magentoProduct, $catIdString, false);

        $magentoProduct = $this->setMagentoAttributes($agilityProduct, $magentoProduct);

        //Images - need to cater for videos as well
        $magentoProduct = $this->processImages($agilityProduct, $magentoProduct);

        //variants
        $typeId = $magentoProduct->getTypeId();
        if ($typeId == 'simple') {
            $magentoProduct = $this->processVariants($agilityProduct, $magentoProduct);
        }

        try { //this creates a product with linked simple products and with a link to its category
            $id = $this->productLoader->save($magentoProduct);
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:getProductData product save failed message is {$e->getMessage()}");
        }
    }

    /**
     * Set Magento Values process
     * This method sets the core Magento values on a  product, including the
     * information passed in the magentoCore xml.
     * It also sets the product type, visibility, status and category id.
     *
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @param string $catIdString
     * @return Magento\Catalog\Api\Data\ProductInterface
     */

    protected function setMagentoValues($agilityProduct, $magentoProduct, $catIdString, $option)
    {
        $agilityId = $agilityProduct->getAgilityId();
        $agilityObj = $this->getAgilityObjectId($agilityId);
        $magentoProduct->setCustomAttribute('agilityid', $agilityObj);

        $magentoCore = $agilityProduct->getMagentoCore();

        $sku = $magentoCore->getSku();
        $magentoProduct->setSku($sku);

        $name = $magentoCore->getName();
        $magentoProduct->setName($name);

        $price = $magentoCore->getPrice();
        if ($price) {
            $magentoProduct->setPrice($price);
        } else {
              $magentoProduct->setPrice(0);
        }

        $typeId = $magentoProduct->getTypeId();

        if ($typeId != (\Magento\Downloadable\Model\Product\Type::TYPE_DOWNLOADABLE)) {
            $type = strtolower($magentoCore->getType());
            if ($type) {
                    $magentoProduct->setTypeId($type);
            } else {
                $magentoProduct->setTypeId('simple');
            }

            $weight = $magentoCore->getWeight();
            if ($weight) {
                $magentoProduct->setWeight($weight);
            } else {
                $magentoProduct->setWeight(0);
            }
        }

        $attributeSetName = $magentoCore->getAttributesetname();
        $skeletonId = $this->getDefaultAttributeSetId();
        if ($attributeSetName) {
            $attributeSetId = $this->getMagentoAttribSets($attributeSetName);
            if ($attributeSetId) {
                $magentoProduct->setAttributeSetId($attributeSetId);
            } else {
                $magentoProduct->setAttributeSetId($skeletonId);
            }
        } else {
            $magentoProduct->setAttributeSetId($skeletonId);
        }

        $quantity = $magentoCore->getQuantity();
        $flagStock = 0;
        if ($quantity>0) {
                $flagStock = 1;
        }

        $inStock = $magentoCore->getInstock();
        if ($inStock == 'Yes') {
            $flagStock = 1;
        }

        if ($flagStock == 1) {
            $magentoProduct->setStockData(
                ['use_config_manage_stock' => 1, 'qty' => $quantity,
                            'is_qty_decimal' => 0, 'is_in_stock' => $flagStock]
            );
            $magentoProduct->setQuantityAndStockStatus(['qty' => $quantity,
                    'is_in_stock' => $flagStock]);
        }

        $magentoProduct->setVisibility(\Magento\Catalog\Model\Product\Visibility::VISIBILITY_NOT_VISIBLE);

        //status is enabled by default
        $magentoProduct->setStatus(\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);
        $status = $magentoCore->getStatus();
        if ($status) {
            $status = strtolower($status);
            if ($status == 'No') {
                $magentoProduct->setStatus(\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_DISABLED);
            }
        }

        //this section sets the category the product belongs to
        if ($catIdString) {
                $magentoProduct->setCustomAttribute('category_ids', $catIdString);
        } else {
            //find the parent category by id
            $parentId = $this->getParentId($agilityId, 'category', $option);
            if ($parentId > 1) {
                $catIdString = strval($parentId);
                $magentoProduct->setCustomAttribute('category_ids', $catIdString);
            }
        }

        return $magentoProduct;
    }

    /**
     * Update Magento Product process
     * This method updates the existing Magento product custom attributes
     * and core values.
     *
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @param string $catIdString
     */

    protected function updateProductValues($agilityProduct, $magentoProduct, $catIdString)
    {
        $magentoCore = $agilityProduct->getMagentoCore();
        //product type may be passed on the magento core
        $typeId = strtolower($magentoCore->getType());
        $sku = $magentoCore->getSku();

        if (!$typeId) {
            //otherwise get existing type id
            $typeId = $magentoProduct->getTypeId();
        }

        if ($typeId == (\Magento\Downloadable\Model\Product\Type::TYPE_DOWNLOADABLE)) {
            //update for downloadable products
            $magentoProduct = $this->setDownloadable($agilityProduct, $magentoProduct);
        }

        if ($magentoCore) {
            $sku = $magentoCore->getSku();
            $magentoProduct->setSku($sku);

            $name = $magentoCore->getName();
            if ($name) {
                $magentoProduct->setName($name);
                $magentoProduct->addAttributeUpdate('name', $name, 0);
            }

            $price = $magentoCore->getPrice();
            if ($price) {
                $magentoProduct->setPrice($price);
                $magentoProduct->addAttributeUpdate('price', $price, 0);
            } else {   //product must have a price set
                $magentoProduct->setPrice(0);
                $magentoProduct->addAttributeUpdate('price', 0, 0);
            }

            //downloadable products have no weight
            if ($typeId != (\Magento\Downloadable\Model\Product\Type::TYPE_DOWNLOADABLE)) {
                $weight = $magentoCore->getWeight();
                if ($weight) {
                    $magentoProduct->setWeight($weight);
                    $magentoProduct->addAttributeUpdate('weight', $weight, 0);
                }
            }

            $attributeSetName = $magentoCore->getAttributesetname();
            $skeletonId = $this->getDefaultAttributeSetId();

            if ($attributeSetName) {
                $attributeSetId = $this->getMagentoAttribSets($attributeSetName);
                if ($attributeSetId) {
                    $magentoProduct->setAttributeSetId($attributeSetId);
                } else {
                    $magentoProduct->setAttributeSetId($skeletonId);
                }
            } else {
                $magentoProduct->setAttributeSetId($skeletonId);
            }

            $flagStock = 0;

            $inStock = $magentoCore->getInstock();
            if ($inStock == 'Yes') {
                $flagStock = 1;
            }

            $quantity = $magentoCore->getQuantity();
            if ($quantity>0) {
                $flagStock = 1;
                $magentoProduct->setStockData(
                    ['use_config_manage_stock' => 1, 'qty' => $quantity,
                                'is_qty_decimal' => 0, 'is_in_stock' => $flagStock]
                );
                $magentoProduct->setQuantityAndStockStatus(['qty' => $quantity,
                        'is_in_stock' => $flagStock]);
            }
        }

        //this section adds/updates attributes
        $attribute = $agilityProduct->getAttribute();
        if (!$attribute) {
            $attributes = $agilityProduct->getAttributes();

            if ($attributes) {
                foreach ($attributes as $oneAttribute) {
                    $magentoProduct = $this->updateProductAttributes($oneAttribute, $magentoProduct);
                }
            }
        } else {
            $magentoProduct = $this->updateProductAttributes($attribute, $magentoProduct);
        }

        $magentoProduct = $this->processImages($agilityProduct, $magentoProduct);

        $magentoProduct->setTypeId($typeId);
        $magentoProduct->setStoreId(0);

        //for configurable products, the options are updated
        if ($typeId == (\Magento\ConfigurableProduct\Model\Product\Type\Configurable::TYPE_CODE)) {
            $optionIds = [];
            $options = [];
            //this bit updates or creates options
            $option = $agilityProduct->getOption();
            if (!$option) {
                $options = $agilityProduct->getOptions();
                if ($options) {
                    foreach ($options as $oneOption) {
                        $attribute = $oneOption->getAttribute();
                        if (!$attribute) {
                            $attributes = $oneOption->getAttributes();
                            foreach ($attributes as $oneAttribute) {
                                $this->checkAgilityAttributes($oneAttribute, $oneOption);
                            }
                        } else {
                            $this->checkAgilityAttributes($attribute, $oneOption);
                        }
                        $id = $this->checkOption($oneOption, "");
                        if ($id) {
                            array_push($optionIds, $id);
                        }
                    }
                }
            } else { //one option
                $attribute = $option->getAttribute();
                if (!$attribute) {
                    $attributes = $option->getAttributes();
                    foreach ($attributes as $oneAttribute) {
                        $this->checkEavAttribute($oneAttribute, $option);
                    }
                } else {
                    $this->checkEavAttribute($attribute, $option);
                }
                $id = $this->checkOption($option, "");
                if ($id) {
                    $optionIds[] = $id;
                }
                $options[] = $option;
            }

            if ($options) {
                if ($magentoProduct) {
                    $magentoProduct = $this->createLinkToSimpleProducts($optionIds, $magentoProduct, $options);
                }
            }
        }

        try {
            $this->productLoader->save($magentoProduct);
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:updateProductValues product save failed for sku {$sku} with message {$e->getMessage()}");
        }
    }

    /**
     * Update Magento Product option process
     * This method updates the existing Magento product option custom attributes
     * and core values.
     *
     * @param  Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     */

    protected function updateOptionValues($agilityProduct, $magentoProduct)
    {

        $magentoCore = $agilityProduct->getMagentoCore();
        if ($magentoCore) {
            $sku = $magentoCore->getSku();
            $magentoProduct->setSku($sku);

            $name = $magentoCore->getName();
            if ($name) {
                $magentoProduct->setName($name);
                $magentoProduct->addAttributeUpdate('name', $name, 0);
            }

            $price = $magentoCore->getPrice();
            if ($price) {
                $magentoProduct->setPrice($price);
                $magentoProduct->addAttributeUpdate('price', $price, 0);
            } else { //product must have a price set
                $magentoProduct->setPrice(0);
                $magentoProduct->addAttributeUpdate('price', 0, 0);
            }

            $weight = $magentoCore->getWeight();
            if ($weight) {
                $magentoProduct->setWeight($weight);
                $magentoProduct->addAttributeUpdate('weight', $weight, 0);
            }

            $skeletonId = $this->getDefaultAttributeSetId();

            $attributeSetName = $magentoCore->getAttributesetname();
            if ($attributeSetName) {
                $attributeSetId = $this->getMagentoAttribSets($attributeSetName);
                if ($attributeSetId) {
                    $magentoProduct->setAttributeSetId($attributeSetId);
                } else {
                    $magentoProduct->setAttributeSetId($skeletonId);
                }
            } else {
                $magentoProduct->setAttributeSetId($skeletonId);
            }

            $flagStock = 0;

            $inStock = $magentoCore->getInstock();
            if ($inStock == 'Yes') {
                $flagStock = 1;
            }

            $quantity = $magentoCore->getQuantity();
            if ($quantity>0) {
                $flagStock = 1;
                $magentoProduct->setStockData(
                    ['use_config_manage_stock' => 1, 'qty' => $quantity,
                                'is_qty_decimal' => 0, 'is_in_stock' => $flagStock]
                );
                $magentoProduct->setQuantityAndStockStatus(['qty' => $quantity,
                        'is_in_stock' => $flagStock]);
                $typeId = 'simple';
            }
        }

        $attribute = $agilityProduct->getAttribute();
        if (!$attribute) {
            $attributes = $agilityProduct->getAttributes();

            if ($attributes) {
                foreach ($attributes as $oneAttribute) {
                    $magentoProduct = $this->updateProductAttributes($oneAttribute, $magentoProduct);
                }
            }
        } else {
            $magentoProduct = $this->updateProductAttributes($attribute, $magentoProduct);
        }

        $magentoProduct = $this->processImages($agilityProduct, $magentoProduct);

        $magentoProduct->setStoreId(0);

        try {
            $id = $this->productLoader->save($magentoProduct);
            if ($id) {
                $optionId = $id->getId($id);
                return $optionId;
            }
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:updateOptionValues product save failed for
                {$sku} with message {$e->getMessage()}");
        }
    }

    /**
     * Update Product Attributes process
     * This method updates attributes on an existing Magento product.
     *
     * @param Agility\Import\Api\Data\AttributeInterface $attribute
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @return Magento\Catalog\Api\Data\ProductInterface
     */

    protected function updateProductAttributes($attribute, $magentoProduct)
    {
        $attrName = $attribute->getName();
        $cleanAttrName = $this->convertText($attrName);
        $attrValue = $attribute->getValue();
        $multiValue = $this->checkArray($attrValue);
        $optionValueArray = [];

        if ($multiValue) {
            $result = count($multiValue);
            if ($result == 1) {
                if ($attrValue == '[Yes]' || $attrValue == '[No]') {
                    if ($attrValue == '[Yes]') {
                        $attrValue = 1;
                    } else {
                        $attrValue = 0;
                    }
                    $magentoProduct->setData($cleanAttrName, $attrValue);
                    $magentoProduct->setData('store_id', 0);
                    $magentoProduct->setStoreId(0);
                    $magentoProduct->getResource()->saveAttribute($magentoProduct, $cleanAttrName);
                    return $magentoProduct;
                }
            }
            foreach ($multiValue as $oneValue) {
                $optionValue = $this->getOptionId($cleanAttrName, $oneValue);
                array_push($optionValueArray, $optionValue);
            }
            $listOptions = implode(',', ($optionValueArray));
            $magentoProduct->setData($cleanAttrName, $listOptions);
            $magentoProduct->setData('store_id', 0);
            $magentoProduct->setStoreId(0);
            $magentoProduct->getResource()->saveAttribute($magentoProduct, $cleanAttrName);
        } else { //standard attribute
            $optionValue = $this->getOptionId($cleanAttrName, $attrValue);
            if ($optionValue) {
                $magentoProduct->setData($cleanAttrName, $optionValue);
            } else {
                $magentoProduct->setData($cleanAttrName, $attrValue);
            }
            $magentoProduct->setData('store_id', 0);
            $magentoProduct->setStoreId(0);
            $magentoProduct->getResource()->saveAttribute($magentoProduct, $cleanAttrName);
        }

        return $magentoProduct;
    }

    /**
     * Set Magento Product Attributes process
     * This method sets the attributes on an Magento product.
     *
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @return Magento\Catalog\Api\Data\ProductInterface
     */

    protected function setMagentoAttributes($agilityProduct, $magentoProduct)
    {
        $attribute = $agilityProduct->getAttribute();
        if (!$attribute) {
            $attributes = $agilityProduct->getAttributes();

            if ($attributes) {
                foreach ($attributes as $oneAttribute) {
                    $magentoProduct = $this->setProductAttributes($oneAttribute, $magentoProduct);
                }
            } else { //no attributes
                return $magentoProduct;
            }
        } else {
            $magentoProduct = $this->setProductAttributes($attribute, $magentoProduct);
        }

        return $magentoProduct;
    }

    /**
     * Set the images on a Magento product
     * This method creates an array of media gallery objects which are set on
     * the magento product
     *
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @return Magento\Catalog\Api\Data\ProductInterface
     */

    public function processImages($agilityProduct, $magentoProduct)
    {
        $image = $agilityProduct->getImage();
        $mgEntries = [];
        $position = 0;

        if (!$image) {
            $images = $agilityProduct->getImages();
            if (!$images) {
                return $magentoProduct; //no images
            }
            $mgEntries = $this->setMediaGallery($images, $position, $mgEntries);
        } else {
            $images[] = $image;
            $mgEntries = $this->setMediaGallery($images, $position, $mgEntries);
        }

        $magentoProduct->setMediaGalleryEntries($mgEntries);

        return $magentoProduct;
    }

    /**
     * Set the media gallery object
     * This method creates each media gallery object and adds it to an array of
     * media gallery entries
     *
     * @param gility\Import\Api\Data\ImageInterface[] $images
     * @param int $position
     * @param array $mgEntries
     * @return \Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryInterface array
     */

    public function setMediaGallery($images, $position, $mgEntries)
    {
        foreach ($images as $oneImage) {
            $mgEntry = 
                $this->objectManager->create('\Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryInterface');
            $imagePath = $oneImage->getPath();

            if ($imagePath != null) {
                $fileType = "image/{$oneImage->getFiletype()}";
                $fileType = strtolower($fileType);
                if (!$fileType) {
                    //fallback value if none found from name
                    $fileType = 'image/png';
                    $imageExt = pathinfo(
                        parse_url($imagePath)['path'],
                        PATHINFO_EXTENSION
                    );
                    if ($imageExt == 'jpg') {
                        $imageExt = 'jpeg'; //needs to match on mime types
                    }
                    if ($imageExt != null) {
                        $fileType = "image/{$imageExt}";
                    }
                }

                $type = $oneImage->getType();

                if (!$type) {
                    //this is default if nothing found from Agility
                    $type = 'image';
                }
                $fileok = @fopen($imagePath, "rb");

                if ($fileok == true) {
                    $fileData = file_get_contents($imagePath);
                    if ($fileData) {
                        $imageLabel = $oneImage->getLabel();
                        $mgEntry->setLabel($imageLabel);
                        $mgEntry->setDisabled(false);
                        $mgEntry->setFile($imagePath);
                        $mgEntry->setTypes([$type]); //thumbnail etc
                        $mgEntry->setMediaType('image');
                        $mgEntry->setPosition($position);
                        $imageData = base64_encode($fileData);
                        $imageContent = 
                            $this->objectManager->create('\Magento\Framework\Api\Data\ImageContentInterface');
                        $imageContent->setName($imageLabel);
                        $imageContent->setType($fileType);
                        $imageContent->setBase64EncodedData($imageData);
                        $mgEntry->setContent($imageContent);
                        array_push($mgEntries, $mgEntry);
                        $position++;
                    }
                }
            }
        }
        return $mgEntries;
    }

    /**
     * Set downloadable - this method creates a Magento product of type
     * downloadable. It checks if the agility product has downloadable links
     * and samples on it.
     * Each downloadable link and sample are added to an array.
     * The downloadable arrays are set as extension attributes on the product
     * and the product type is set to downloadable.
     *
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @return Magento\Catalog\Api\Data\ProductInterface
     */

    public function setDownloadable($agilityProduct, $magentoProduct)
    {
        $download = $agilityProduct->getDownloadlink();
        $sortOrder = 0;
        $links = [];

        if (!$download) {
            $downloads = $agilityProduct->getDownloadlinks();
            if (!$downloads) {
                return $magentoProduct; //no downloads
            }
            foreach ($downloads as $onedownload) {
                $sortOrder = $sortOrder++;
                $magentoLink = $this->setDownloadableLinks($onedownload, $magentoProduct, $sortOrder);
                $links[] = $magentoLink;
            }
        } else { //just one download
            $sortOrder = 1;
            $magentoLink = $this->setDownloadableLinks($download, $magentoProduct, $sortOrder);
            $links[] = $magentoLink;
        }

        if ($links) {
            //has populated extension attributes for links
            $extension = $magentoProduct->getExtensionAttributes();
            $extension->setDownloadableProductLinks($links);

            $sampleSortOrder = 0;
            $samplesarray = [];
            $sample = $agilityProduct->getDownloadsample();
            if (!$sample) {
                $samples = $agilityProduct->getDownloadSamples();
                if ($samples) {
                    foreach ($samples as $onesample) {
                        $sampleSortOrder = $sampleSortOrder++;
                        $sample = $this->setDownloadableSamples($onesample, $magentoProduct, $sampleSortOrder);
                        $samplesarray[] = $sample;
                    }
                }
            } else { //just one sample
                $sampleSortOrder = 1;
                $sample = $this->setDownloadableSamples($sample, $magentoProduct, $sampleSortOrder);
                $samplesarray[] = $sample;
            }

            if ($samplesarray) {
                $extension->setDownloadableProductSamples($samplesarray);
            }

            $magentoProduct->setExtensionAttributes($extension);
            $magentoProduct->setTypeId(\Magento\Downloadable\Model\Product\Type::TYPE_DOWNLOADABLE);
        }

        return $magentoProduct;
    }

    /**
     * Set downloadable links - this method creates a downloadable link object
     * and returns it to be added to an array
     *
     * @param  Agility\Import\Api\Data\DownloadLinkInterface $agilitylink
     * @param  Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @parm int $sortOrder
     * @return Magento\Downloadable\Api\Data\LinkInterfaceFactory
     */

    public function setDownloadableLinks($agilitylink, $magentoProduct, $sortOrder)
    {

        $magentoProduct->setStoreId(0);
        $magentoLink = $this->objectManager->create('Magento\Downloadable\Api\Data\LinkInterfaceFactory')->create();

        $magentoLink->setStoreId(0);
        $magentoLink->setWebsiteId(0);

        $linkTitle = $agilitylink->getTitle();
        $magentoLink->setTitle($linkTitle);

        $soint = (int)$sortOrder;
        $magentoLink->setSortOrder($soint);

        $isShareable = $agilitylink->getIsshareable();
        if ($isShareable == 'Yes') {
            $magentoLink->setIsShareable(1);
        } else {
            $magentoLink->setIsShareable(0);
        }

        $magentoLink->setPrice($agilitylink->getPrice());

        $numDownloads = $agilitylink->getNumdownloads();

        if ($numDownloads) {
            $int = (int)$numDownloads;
            $magentoLink->setNumberOfDownloads($int);
        } else {
            //set to 0 for unlimited downloads
            $magentoLink->setNumberOfDownloads(0);
        }

        $imageName = $agilitylink->getImagename();
        if (!$imageName) {
            $imageName = $linkTitle;
        }

        $imagePath = $agilitylink->getImagepath();

        if ($imagePath) {
            if (stripos($imagePath, "http") !== false) {
                $magentoLink->setLinkType(\Magento\Downloadable\Helper\Download::LINK_TYPE_URL);
                $contentType = 'link_file';
                $magentoLink->setLinkFile(null);
                $magentoLink->setLinkUrl($imagePath);
                $fileok = @fopen($imagePath, "rb");
                if ($fileok == true) {
                    $fileData = base64_encode(file_get_contents($imagePath));
                }
            } else {
                $magentoLink->setLinkType(\Magento\Downloadable\Helper\Download::LINK_TYPE_FILE);
                $contentType = $contentType = 'link_file';
                $magentoLink->setLinkFile($imagePath);
                $fileok = @fopen($imagePath, "rb");
                if ($fileok == true) {
                    $fileData = base64_encode(file_get_contents($imagePath));
                }
                $magentoLink->setLinkUrl(null);
            }

            if ($fileData) {
                $content = $this->objectManager->
                    create('Magento\Downloadable\Api\Data\File\ContentInterfaceFactory')->create();
                $content->setFileData($fileData);
                $content->setName($imageName);
                $magentoLink->setLinkFileContent($content);
            }
        }

        $linksamplename = $agilitylink->getLinksamplename();
        if (!$linksamplename) {
            $linksamplename = $linkTitle;
        }

        $sampleimagePath = $agilitylink->getLinksamplepath();

        if ($sampleimagePath) {
            if (stripos($sampleimagePath, "http") !== false) {
                $magentoLink->setSampleType(\Magento\Downloadable\Helper\Download::LINK_TYPE_URL);
                $contentType = 'link_sample_file';
                $magentoLink->setSampleFile(null);
                $magentoLink->setSampleUrl($sampleimagePath);
                $fileok = @fopen($sampleimagePath, "rb");
                if ($fileok == true) {
                    $fileData = base64_encode(file_get_contents($sampleimagePath));
                }
            } else {
                $magentoLink->setSampleType(\Magento\Downloadable\Helper\Download::LINK_TYPE_FILE);
                $contentType = 'link_sample_file';
                $magentoLink->setSampleFile($sampleimagePath);
                $magentoLink->setSampleUrl(null);
                $fileok = @fopen($sampleimagePath, "rb");
                if ($fileok == true) {
                    $fileData = base64_encode(file_get_contents($sampleimagePath));
                }
            }

            if ($fileData) {
                $content = $this->objectManager->
                    create('Magento\Downloadable\Api\Data\File\ContentInterfaceFactory')->create();
                $content->setFileData($fileData);
                $content->setName($linksamplename);
                $magentoLink->setSampleFileContent($content);
            }
        }

        $separately = $agilitylink->getPurchasedseparately();
        if ($separately) {
            $magentoProduct->setCustomAttribute('links_purchased_separately', true);
        }

        return $magentoLink;
    }

    /**
     * Set downloadable samples - this method creates a downloadable sample
     * object and returns it to be added to an array
     *
     * @param Agility\Import\Api\Data\DownloadSampleInterface $agilitysample
     * @param  Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @param int $sampleSortOrder
     * @return Magento\Downloadable\Api\Data\SampleInterfaceFactory
     */

    public function setDownloadableSamples($agilitysample, $magentoProduct, $sampleSortOrder)
    {

        $magentoSample = $this->objectManager->
            create('Magento\Downloadable\Api\Data\SampleInterfaceFactory')->create();
        $magentoSample->setStoreId(0);

        $soint = (int)$sampleSortOrder;
        $magentoSample->setSortOrder($soint);
        $magentoSample->setTitle($agilitysample->getTitle());

        $imageName = $agilitysample->getSamplename();
        if (!$imageName) {
            $imageName = $agilitysample->getTitle();
        }

        $sampleimagePath = $agilitysample->getSamplepath();

        if ($sampleimagePath) {
            if (stripos($sampleimagePath, "http") !== false) {
                $magentoSample->setSampleType(\Magento\Downloadable\Helper\Download::LINK_TYPE_URL);
                $magentoSample->setSampleFile(null);
                $magentoSample->setSampleUrl($sampleimagePath);
                $fileok = @fopen($sampleimagePath, "rb");
                if ($fileok == true) {
                    $fileData = base64_encode(file_get_contents($sampleimagePath));
                }
            } else {
                $magentoSample->setSampleType(\Magento\Downloadable\Helper\Download::LINK_TYPE_FILE);
                $magentoSample->setSampleFile($sampleimagePath);
                $magentoSample->setSampleUrl(null);
                $fileok = @fopen($sampleimagePath, "rb");
                if ($fileok == true) {
                    $fileData = base64_encode(file_get_contents($sampleimagePath));
                }
            }

            if ($fileData) {
                $content = $this->objectManager->
                    create('Magento\Downloadable\Api\Data\File\ContentInterfaceFactory')->create();
                $content->setFileData($fileData);
                $content->setName($imageName);
                $magentoSample->setSampleFileContent($content);
            }
        }

        return $magentoSample;
    }

    /**
     * Process Relations
     * For each product or product option, this method processes related skus,
     * grouped and bundled products. Note that related and grouped products
     * are built in same way and so can use the same methods.
     * The method looks for the product in Magento, as it should have been
     * created before reaching this method, which is done at the end of
     * processing. The product needs to be already existing before this method
     * can process it. It will be called for both product update and create.
     * At the end of this method, a check is done to see if the product has any
     * attributes that should be removed, which is the final part of processing.
     *
     * @param Agility\Import\Api\Data\ProductInterface  $agilityProduct
     */

    public function processRelations($agilityProduct)
    {
        $bundleLinks = [];
        $productLinkGroup = [];
        $bundlePosition = 0;
        $productLinks = [];
        $linkExists = false;

        $magentoCore = $agilityProduct->getMagentoCore();
        $sku = $magentoCore->getSku();

        $magentoProduct = $this->getProductBySku($agilityProduct);

        if ($magentoProduct) {
            $typeId = $magentoProduct->getTypeId();
            //check if there are any grouped products - need to set these
            //on the product in same way as relations
            $group = $agilityProduct->getGroup();
            if (!$group) {
                $groups = $agilityProduct->getGroups();
                if ($groups) {
                    foreach ($groups as $oneGroup) {
                        $productLinkGroup = $this->getRelatedSkus($oneGroup, $agilityProduct);
                        if ($productLinkGroup) {
                            $productLinks = array_merge($productLinks, $productLinkGroup);
                        }
                    }
                } else {
                    //no groups - for updates - if there are any existing groups
                    //on the product, remove them
                    $existingLink = $magentoProduct->getProductLinks();
                    if ($existingLink) {
                        foreach ($existingLink as $oneLink) {
                            $linkType = $oneLink->getLinkType();
                            if ($linkType == 'associated') {
                                $linkExists = true;
                            }
                        }
                    }
                }
            } else { //one group
                $productLinkGroup = $this->getRelatedSkus($group, $agilityProduct);
                if ($productLinkGroup) {
                    $productLinks = array_merge($productLinks, $productLinkGroup);
                }
            }
            $relation = $agilityProduct->getRelatedSku();
            if (!$relation) {
                $relations = $agilityProduct->getRelatedSkus();
                if ($relations) {
                    foreach ($relations as $oneRelation) {
                        $productLink = $this->getRelatedSkus($oneRelation, $agilityProduct);
                        if ($productLink) {
                            $productLinks = array_merge($productLinks, $productLink);
                        }
                    }
                } else {
                    //no relations - for updates - if there are any existing
                    //relations on the product, set the link exists flag
                    $existingLink = $magentoProduct->getProductLinks();
                    if ($existingLink) {
                        foreach ($existingLink as $oneLink) {
                            $linkType = $oneLink->getLinkType();
                            if ($linkType == 'related' || $linkType == 'upsell' || $linkType == 'crossell') {
                                $linkExists = true;
                            }
                        }
                    }
                }
            } else { //one relation
                $productLink = $this->getRelatedSkus($relation, $agilityProduct);
                if ($productLink) {
                    $productLinks = array_merge($productLinks, $productLink);
                }
            }

            //remove any existing links that are not on input file
            if ($linkExists) {
                $magentoProduct = $this->removeLinks($magentoProduct);
                $linkExists = false;
            }

            if ($productLinks) { // add any new links
                $magentoProduct->setProductLinks($productLinks);
                if ($productLinkGroup) {
                    $magentoProduct->setTypeId('grouped');
                } else {
                    $magentoProduct->setTypeId($typeId);
                }
                try {
                    $id = $this->productLoader->save($magentoProduct);
                } catch (\Exception $e) {
                    $this->logger->info("AgilityImport:processRelations product save failed for 
                        {$sku} with message {$e->getMessage()}");
                }
            }
            //process bundle products here
            //get any bundle options on the product and create a bundle option
            //object. Set the bundle options and links as an extension attribute
            //on the product.

            $bundleOptions = $agilityProduct->getBundleOption();
            if ($bundleOptions) {
                $bundleoption = $this->getBundleOptions($bundleOptions, $agilityProduct, $bundlePosition);
                if ($bundleoption) {
                    $bundle = $agilityProduct->getBundleLink();
                    if (!$bundle) {
                        $bundles = $agilityProduct->getBundleLinks();
                        if ($bundles) {
                            foreach ($bundles as $oneBundle) {
                                $bundleLink = $this->getBundleLinks($oneBundle);
                                if ($bundleLink) {
                                    $bundleLinks = array_merge($bundleLinks, $bundleLink);
                                }
                            }
                        }  //no bundles - can't see anyone removing bundles -
                        //more likely to just amend them
                    } else { //one bundle
                        $bundleLink = $this->getBundleLinks($bundle);
                        if ($bundleLink) {
                            $bundleLinks = array_merge($bundleLinks, $bundleLink);
                        }
                    }
                    if ($bundleLinks) {
                        $bundleoption->setProductLinks($bundleLinks);
                        $extension = $magentoProduct->getExtensionAttributes();
                        $extension->setBundleProductOptions([$bundleoption]);
                        $magentoProduct->setExtensionAttributes($extension);
                        $priceType = strtolower($bundleOptions->getPriceType());

                        if ($priceType == 'fixed') {
                            $magentoProduct->setCustomAttribute(
                                'price_type',
                                (\Magento\Bundle\Model\Product\Price::PRICE_TYPE_FIXED)
                            );
                        } elseif ($priceType == 'dynamic') {
                            $magentoProduct->setCustomAttribute(
                                'price_type',
                                (\Magento\Bundle\Model\Product\Price::PRICE_TYPE_DYNAMIC)
                            );
                        }
                        $shipmentType = strtolower($bundleOptions->getShipmentType());
                        if ($shipmentType == 'separately') {
                            $magentoProduct->setShipmentType(1);
                        }
                        $magentoProduct->setCustomAttribute('price_view', 1);
                        $magentoProduct->setTypeId(\Magento\Catalog\Model\Product\Type::TYPE_BUNDLE);
                        try {
                            $id = $this->productLoader->save($magentoProduct);
                        } catch (\Exception $e) {
                            $this->logger->info("AgilityImport:processRelations product save failed 
                            		    on bundle for {$sku} with message {$e->getMessage()}");
                        }
                    }
                }
            }
            //need to do this at the end of everything as saving the product will re-add any old attributes!

            $this->checkAttributesToDelete($agilityProduct, $magentoProduct);
        }
    }

    /**
     * Get Bundle Options
     * This method creates a bundle option object and sets the values on it from
     * the Agility product. The option object is returned.
     *
     * @param Agility\Import\Api\Data\BundleOptionInterface $bundleOptions
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @param int $bundlePosition
     * @return \Magento\Bundle\Api\Data\OptionInterface
     */

    protected function getBundleOptions($bundleOptions, $agilityProduct, $bundlePosition)
    {

        /** @var \Magento\Bundle\Api\Data\OptionInterface $option */
        $option = $this->objectManager->create(\Magento\Bundle\Api\Data\OptionInterface::class);

        $bundleTitle = $bundleOptions->getTitle();
        if ($bundleTitle) {
            $option->setTitle($bundleTitle);
        }
        $bundleType = $bundleOptions->getType();
        if ($bundleType) {
            $option->setType($bundleType);
        }
        $magentoCore = $agilityProduct->getMagentoCore();
        $sku = $magentoCore->getSku();
        $option->setSku($sku);

        $bundleRequired = strtolower($bundleOptions->getIsRequired());
        if ($bundleRequired == 'yes') {
            $option->setRequired(1);
        } else {
            $option->setRequired(0);
        }

        $bundlePosition++;
        $option->setPosition($bundlePosition);

        return $option;
    }

    /**
     * Get Bundle Links
     * This method creates a link interface object and sets the values on it
     * from the Agility product. The link is pushed onto a productlinkarray
     * which is returned.
     *
     * @param Agility\Import\Api\Data\BundleLinkInterface $bundle
     * @return array
     */

    protected function getBundleLinks($bundle)
    {
        $productLinkArray = [];

        //set up the links for the product
        $link = $this->objectManager->
            create('Magento\Bundle\Api\Data\LinkInterfaceFactory')->create();

        try {
            $linkProduct = $this->productLoader->get($bundle->getSku());
            if ($linkProduct) {
                $link->setSku($linkProduct->getSku());
                $bundleQuantity = $bundle->getQuantity();
                if ($bundleQuantity) {
                    $link->setQty($bundleQuantity);
                }

                $bundleCanChangeQty = strtolower($bundle->getCanChangeQuantity());
                if ($bundleCanChangeQty == 'yes') {
                    $link->setCanChangeQuantity(1);
                } else {
                    $link->setCanChangeQuantity(0);
                }

                $isDefault = strtolower($bundle->getIsDefault());
                if ($isDefault == 'yes') {
                    $link->setIsDefault(1);
                }

                $linkPrice = $bundle->getPrice();
                if ($linkPrice) {
                    $link->setPrice($linkPrice);
                }

                array_push($productLinkArray, $link);
            }
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:getBundleLinks get sku failed for
                {$bundle->getSku()} with message {$e->getMessage()} ");
        }

        return $productLinkArray;
    }

    /**
     * Get Related Skus
     * This method gets the relation type from the agility product and calls a
     * method to set the type of product link.
     *
     * @param Agility\Import\Api\Data\RelatedSkuInterface $relation
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @return Magento\Catalog\Api\Data\ProductLinkInterface array
     */

    protected function getRelatedSkus($relation, $agilityProduct)
    {

        $magentoCore = $agilityProduct->getMagentoCore();
        $sku = $magentoCore->getSku();

        $attribute = $relation->getAttribute();

        //should just be one attribute on the relation
        if ($attribute) {
            $productLink = $this->setLinkedProduct($attribute, $sku);
            return $productLink;
        }

    }

    /**
     * Set Linked Product
     * This method looks up the related sku in Magento.
     * If it finds the related sku, it creates a productlinkinterface object.
     * On the product link object, it sets the related sku, the related sku type
     * value, the 'main' sku, and the type of the link (which is derived from
     * the attribute name). The product link object is pushed on to an array
     * which is returned.
     *
     * @param  Agility\Import\Api\Data\AttributeInterface $attribute
     * @param string $sku
     * @return Magento\Catalog\Api\Data\ProductLinkInterface array
     */

    protected function setLinkedProduct($attribute, $sku)
    {
        $productLinkArray = [];
        $existingSku = null;

        $attrValue = $attribute->getValue();
        $attrValue = $this->cleanText($attrValue);

        try {
            $existingSku = $this->productLoader->get($attrValue);
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:setLinkedProduct get product failed {$attrValue} with message {$e->getMessage()}");
        }
        if ($existingSku) {
            $type = $existingSku->getTypeId($attrValue);
            /** @var \Magento\Catalog\Api\Data\ProductLinkInterface $productLink */
            $productLink = $this->objectManager->create('Magento\Catalog\Api\Data\ProductLinkInterface');
            $productLink->setLinkedProductSku($attrValue);
            $productLink->setLinkedProductType($type);
            $productLink->setSku($sku);
            $productLink->setLinkType($attribute->getName());
            $productLink->setPosition(null);
            array_push($productLinkArray, $productLink);
        }

        return $productLinkArray;
    }

    /**
     * Process variants
     * This method processes the variants from Agility - which become product
     * options in Magento. Product options are simple product types in Magento.
     * It is called from the create product code, so the options are created if
     * they are found on a product and then linked back to the parent magento
     * product.
     *
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @return Magento\Catalog\Api\Data\ProductInterface
     */

    protected function processVariants($agilityProduct, $magentoProduct)
    {
        $variant = $agilityProduct->getOption();
        $optionIds = [];
        $variants = [];

        if (!$variant) {
            $variants = $agilityProduct->getOptions();
            $options = [];

            if ($variants) {
                foreach ($variants as $oneVariant) {
                    //create a simple product
                    $optionId = $this->createVariant($oneVariant);
                    if ($optionId) {
                        array_push($optionIds, $optionId);
                    }
                }
            } else { //no variants
                return $magentoProduct;
            }
        } else {
            //this is just one option
            $optionId = $this->createVariant($variant);
            if ($optionId) {
                $optionIds = $optionId;
            }
        }

        if (!$variants) {
            $variants[] = $variant;
        }

        if ($magentoProduct) {
            $magentoProduct = $this->createLinkToSimpleProducts($optionIds, $magentoProduct, $variants);
        }

        return $magentoProduct;
    }

    /**
     * Set Product Attributes
     * This method sets the custom attributes on a magento product.
     * If an attribute has options, the option value is set rather than the
     * actual value passed from Agility.
     *
     * @param Agility\Import\Api\Data\AttributeInterface $attribute
     * @param  Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @return Magento\Catalog\Api\Data\ProductInterface
     */

    protected function setProductAttributes($attribute, $magentoProduct)
    {
        $attrName = $attribute->getName();
        $cleanAttrName = $this->convertText($attrName);
        $attrValue = $attribute->getValue();
        $multiValue = $this->checkArray($attrValue);

        if (!$multiValue) {
            $optionValue = $this->getOptionId($cleanAttrName, $attrValue);
            if ($optionValue) {
                $magentoProduct->setCustomAttribute($cleanAttrName, $optionValue);
            } else {
                $magentoProduct->setCustomAttribute($cleanAttrName, $attrValue);
            }
        } else {  //for multi values
            $result = count($multiValue);
            if ($result == 1) {
                if ($attrValue == '[Yes]' || $attrValue == '[No]') {
                    if ($attrValue == '[Yes]') {
                        $attrValue = 1;
                    } else {
                        $attrValue = 0;
                    }
                    $magentoProduct->setCustomAttribute($cleanAttrName, $attrValue);
                    return $magentoProduct;
                }
            }

            $magentoProduct = $this->setOptionIds($cleanAttrName, $multiValue, $magentoProduct);
        }

        return $magentoProduct;
    }

    /**
     * Create Link To Simple Products
     * This method handles up to 2 attribute variations - for example color and
     * size.
     *
     * This method is called for both product updates and creates, and for
     * product/variant moves.
     * Get the extension attributes on the existing magento product and see if
     * it has any attribute data on there already (this is to cater for updates)
     * If there are any existing values, break them down into 2 arrays, one for
     * each attribute, and add the values to the option values array.
     * Then get the variants on the agility product and create the 2 arrays of
     * attribute linking information. For updates, this will add records to the
     * existing arrays, and will not duplicate entries.
     * Next create the configurableAttributesData arrays, for each EAV
     * attribute. Finally set the configurable attributes as an extension
     * attribute on the parent magento product. For updates, merge the option
     * ids with any existing option ids. The optionids are passed to this method
     * for all of the child options created below the parent.
     *
     * @param array $optionIds
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @param Agility\Import\Api\Data\OptionInterface $variants
     * @return Agility\Import\Api\Data\ProductInterface
     */

    protected function createLinkToSimpleProducts($optionIds, $magentoProduct, $variants)
    {
        //for each variant on a product, get the variant attributes that we can
        //use to link the variant to the product
        //caters for 2 attribute options only

        $position1 = 0;
        $position2 = 0;
        $attributeValues1 = [];
        $attributeValues2 = [];
        $attributeData = [];
        $configurableAttributesData = [];

        $optionValues = [];
        $eavIds1 = [];
        $eavIds2 = [];

        //this section is for product updates
        //get the existing product attribute data and break down into 2 arrays
        $configurableOptionCollection = $magentoProduct->getExtensionAttributes()->getConfigurableProductOptions();

        if ($configurableOptionCollection) {
            $configurableAttributeData = $this->objectManager->create('\Magento\ConfigurableProduct\Model\ConfigurableAttributeData');
            $attributesData = $configurableAttributeData->getAttributesData($magentoProduct, $configurableOptionCollection);

            if ($attributesData) {
                $attributeData = $attributesData['attributes'];
                //up to 2 arrays here to cater for
                foreach ($attributeData as $attribData) {
                    $existId = $attribData['id'];
                    if ($position1 > 0) {//this is for the second eav id
                        $position2++;
                        array_push($eavIds2, $existId);
                        $existLabel = $attribData['label'];
                        $existCode = $attribData['code'];
                        $existOptions = $attribData['options'];
                        foreach ($existOptions as $existOption) {
                            $existOptionId = $existOption['id'];
                            $existOptionLabel = $existOption['label'];
                            $attributeValues2[] = [
                                    'label' => $existCode,
                                    'attribute_id' => $existId,  //eav id
                                    'value_index' => $existOptionId,
                            ];
                            array_push($optionValues, $existOptionId);
                        }
                    } else { //for first eav id
                        array_push($eavIds1, $existId);
                        $position1++;
                        $existLabel = $attribData['label'];
                        $existCode = $attribData['code'];
                        $existOptions = $attribData['options'];
                        foreach ($existOptions as $existOption) {
                            $existOptionId = $existOption['id'];
                            $existOptionLabel = $existOption['label'];
                            $attributeValues1[] = [
                                    'label' => $existCode,
                                    'attribute_id' => $existId,  //eav id
                                    'value_index' => $existOptionId,
                            ];
                            array_push($optionValues, $existOptionId);
                        }
                    }
                }
            }
        }

        //this bit gets up to 2 variant attributes to store as 'super attributes'
        //to link to the main product
        //for each attribute, get the unique option value (for example, on color
        //get the option value for red - if there are variants that both have
        //red - then only get it once).
        //at the end of this section, you have 2 arrays - should be for example
        //size in one with all the unique option values, and color in the
        //other array, with all the unique option values.

        foreach ($variants as $variant) {
            $attrib = $variant->getAttribute();
            if (!$attrib) {
                $attribs = $variant->getAttributes();
                if ($attribs != null) {
                    foreach ($attribs as $attribute) {
                        $attribName = $attribute->getName();
                        $cleanAttrName = $this->convertText($attribName);
                        $attribValue = $attribute->getValue();
                        $attribValue = $this->cleanText($attribValue);
                        $optionValue = $this->getOptionId($cleanAttrName, $attribValue);
                        if ($optionValue) {
                            $eavAttrib = $this->getAttribute($cleanAttrName);
                            if ($eavAttrib) {
                                $eavId = $eavAttrib->getAttributeId();
                                if ($position1 == 0) {
                                    array_push($eavIds1, $eavId);
                                    $position1++;
                                }
                                if (!in_array($optionValue, $optionValues)) {
                                    array_push($optionValues, $optionValue);
                                    //must be same variation in each attributeValues
                                    if (in_array($eavId, $eavIds1)) {
                                        $attributeValues1[] = [
                                                'label' => $cleanAttrName,
                                                'attribute_id' => $eavId,
                                                'value_index' => $optionValue,
                                        ];
                                        array_push($eavIds1, $eavId);
                                        $position1++;
                                    } else {
                                        if ($position2 == 0) {
                                            array_push($eavIds2, $eavId);
                                            $position2++;
                                        }
                                        if (in_array($eavId, $eavIds2)) {
                                            $attributeValues2[] = [
                                                'label' => $cleanAttrName,
                                                'attribute_id' => $eavId,
                                                'value_index' => $optionValue,
                                            ];
                                            array_push($eavIds2, $eavId);
                                            $position2++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                $attributeValues2 = []; //initialise second array
                $attribName = $attrib->getName();
                $cleanAttrName = $this->convertText($attribName);
                $attribValue = $attrib->getValue();
                $attribValue = $this->cleanText($attribValue);
                $optionValue = $this->getOptionId($cleanAttrName, $attribValue);
                if ($optionValue) {
                    $eavAttrib = $this->getAttribute($cleanAttrName);
                    if ($eavAttrib) {
                        $eavId = $eavAttrib->getAttributeId();
                        if ($position1 == 0) {
                            array_push($eavIds1, $eavId);
                        }
                        //unique option values
                        if (!in_array($optionValue, $optionValues)) {
                            array_push($optionValues, $optionValue);
                            //must be same variation in each attributeValues
                            if (in_array($eavId, $eavIds1)) {
                                $attributeValues1[] = [
                                        'label' => $cleanAttrName,
                                        'attribute_id' => $eavId,
                                        'value_index' => $optionValue,
                                ];
                                array_push($eavIds1, $eavId);
                                $position1++;
                            }
                        }
                    }
                }
            }
        }

        //now we have the arrays with the (eg: color/size) variation options.
        //Now create the configurable attributes data arrays from this
        if ($attributeValues1) {
            $attribName = $attributeValues1[0]['label'];
            $eavId = $attributeValues1[0]['attribute_id'];
            $eavAttrib = $this->getAttribute($attribName);
            if ($eavAttrib) {
                $configurableAttributesData[] = [
                        'attribute_id' => $eavId,
                        'code' => $eavAttrib->getAttributeCode(),
                        'label' => $eavAttrib->getStoreLabel(),
                        'position' => 0,
                        'values' => $attributeValues1,
                ];
            }
        }

        if ($attributeValues2) {
            $attribName = $attributeValues2[0]['label'];
            $eavId = $attributeValues2[0]['attribute_id'];
            $eavAttrib = $this->getAttribute($attribName);
            if ($eavAttrib) {
                $configurableAttributesData[] = [
                        'attribute_id' => $eavId,
                        'code' => $eavAttrib->getAttributeCode(),
                        'label' => $eavAttrib->getStoreLabel(),
                        'position' => 1,
                        'values' => $attributeValues2,
                ];
            }
        }

        //if we have configurable attributes data arrays - add this to the
        //product, along with a list of all the optionids - that is, the
        //product options ids previously created before coming into this method.
        if ($configurableAttributesData != null) {
            $magentoProduct->setVisibility(\Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH);
            $magentoProduct->setTypeId(\Magento\ConfigurableProduct\Model\Product\Type\Configurable::TYPE_CODE);
            $optionsFactory = $this->objectManager->create(Factory::class);
            $configurableOptions = $optionsFactory->create($configurableAttributesData);
            $extensionConfigurableAttributes = $magentoProduct->getExtensionAttributes();
            $extensionConfigurableAttributes->setConfigurableProductOptions($configurableOptions);
            $existingOptionIds = $extensionConfigurableAttributes->getConfigurableProductLinks();
            //merge the existing option ids for product updates
            if ($existingOptionIds) {
                $optionIds = array_merge($optionIds, $existingOptionIds);
            }
            $extensionConfigurableAttributes->setConfigurableProductLinks($optionIds);
            $magentoProduct->setExtensionAttributes($extensionConfigurableAttributes);
        }

        return $magentoProduct;
    }

    /**
     * Create Variant
     * This method creates a Magento simple product and returns the option id.
     *
     * @param Agility\Import\Api\Data\ProductInterface $agilityObj
     * @return string
     */
    public function createVariant($agilityObj)
    {
        //create the product/variant and set its values
        /** @var \Magento\Catalog\Api\Data\ProductInterface $product */
        $magentoObj = $this->objectManager->create('\Magento\Catalog\Api\Data\ProductInterface');

        $magentoCore = $agilityObj->getMagentoCore();
        $sku = $magentoCore->getSku();

        $magentoObj->setStoreId(0);

        $magentoObj = $this->setMagentoValues($agilityObj, $magentoObj, null, true);

        $magentoObj = $this->setMagentoAttributes($agilityObj, $magentoObj);

        $magentoObj = $this->processImages($agilityObj, $magentoObj);

        try {
            $id = $this->productLoader->save($magentoObj);
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:createVariant save failed for sku {$sku} with message {$e->getMessage()} ");
            return null;
        }

        $optionId = $id->getId($id);

        return $optionId;
    }

    /**
     * tokenize
     * This method takes a string and a delimiter and returns an array of tokens
     * The string is split by the delimiter into tokens.
     *
     * @param string $delimiter
     * @param string $str
     * @return array
     */

    protected function tokenize($delimiter, $str)
    {
        $tokens = [];
        $tok = strtok($str, $delimiter);

        do {
            $tokens[] = $tok;
            $tok = strtok($delimiter);
        } while ($tok !== false);

        return $tokens;
    }


    /**
     * Get Parent Id
     * This method gets the agilityidpath and finds the object of the path,
     * which is the number before the last colon.
     * If the option is set to true, then the grandparent path is found (ie: the
     * number before the second last colon in the string)
     * Finally the id of the parent or grandparent is returned from
     * getObjectById.
     * If no parent id is found, then the default parent of '1' is returned.
     *
     * @param string $agilityId
     * @param Agility\Import\Api\Data\ProductInterface $agilityObj
     * @param string $option
     * @return string
     */

    protected function getParentId($agilityId, $agilityObj, $option)
    {

        $pos = strrpos($agilityId, ":"); // find the last colon separator
        $parentPath = '';                //Agility parent path
        $parentId=1;                    //parentId

        if (!$pos) {
                $parentId = 1;              
        } else {
            $parentPath = substr($agilityId, 0, $pos); //parent directory path
            if ($option) {
                $pos = strrpos($parentPath, ":");
                if ($pos) {
                    // grandparent directory path
                    $grandParentPath = substr($parentPath, 0, $pos);
                    $parentObj = $this->getAgilityObjectId($grandParentPath);
                }
            } else {
                //parent object to search on
                $parentObj = $this->getAgilityObjectId($parentPath);
            }
        }

        if ($agilityObj == 'category') {
            $type = 'category';
        }

        if ($agilityObj == 'option') {
            $type = 'product';
        }

        $parentId = $this->getObjectById($parentObj, $type);
        if (!$parentId) {
            $parentId == 1;
        }

        return $parentId;
    }

    /**
     * Get Magento Attributes
     * This method looks up all of the product attributes on the eav attribute
     * table. For each attribute, the attribute code value is added to an array.
     * An array of existing attribute codes is returned.
     *
     * @return array
     */

    public function getMagentoAttribs()
    {

        $searchCriteria = $this->searchCriteriaBuilder->addFilters([])->create();

        $magentoAttributes = $this->attributeRepository->getList('catalog_product', $searchCriteria);
        $searchItems = $magentoAttributes->getItems();
        foreach ($searchItems as $searchItem) {
            $existingAttrArray[] = $searchItem->getAttributeCode();
        }

        return $existingAttrArray;
    }

    /**
     * Get Magento Attribute Sets
     * This method looks up all of the product attribute sets and looks for a
     * match on the attribute set name passed into the method.
     * If a match is found on the name, then the id of the attribute set is
     * returned.
     *
     * @param string $attrSetName
     * @return string
     */

    public function getMagentoAttribSets($attrSetName)
    {

        $this->searchCriteriaBuilder->addFilters(
            [
                $this->filterBuilder
                ->setField('entity_type_code')
                ->setValue(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE)
                ->setConditionType('eq')
                ->create(),
            ]
        );

        $magentoAttributeSets = $this->attributeSet->getList($this->searchCriteriaBuilder->create());

        $searchItems = $magentoAttributeSets->getItems();
        foreach ($searchItems as $searchItem) {
            $searchAttrSetName = $searchItem->getAttributeSetName();
            if ($searchAttrSetName == $attrSetName) {
                $attrSetId = $searchItem->getAttributeSetId();
                return $attrSetId;
            }
        }
    }

    /**
     * Create Eav Attribute
     * This method creates new attributes on the eav attribute table.
     * Based on the properties of the agility attribute, the method makes
     * decisions about what kind of attribute to create.
     * It then creates a new attribute with a standard set of values.
     * It adds the attribute to the attribute set passed to the program in the
     * magento core. If there is none passed it uses the default attribute set.
     * If the attribute set can't be found, this method will call a method that
     * will create one.
     * If the new attribute is a multiple choice, this method adds the option
     * values for the attribute to Magento.
     *
     * @param string $agilityAttrName
     * @param string $agilityAttrType
     * @param string $agilityAttrValue
     * @param Agility\Import\Api\Data\ProductInterface $agilityObject
     */

    protected function createEavAttribute($agilityAttrName, $agilityAttrType, $agilityAttrValue, $agilityObject)
    {

        $cleanAttrName = $this->convertText($agilityAttrName);
        $frontLabel = $this->createLabel($agilityAttrName);

        $backEndType = 'varchar';
        $attrLength = strlen($agilityAttrValue);
        if ($attrLength > 50) {
            $frontEndIn = 'textarea';
        } else {
            $frontEndIn = 'text';
        }

        //numeric value double has decimal point otherwise an int
        if ($agilityAttrType == '1') {
            $frontEndIn = 'text';
            if (strpos($agilityAttrValue, '.') !== false) {
                $backEndType = 'decimal';
            } else {
                $backEndType = 'int';
            }
        }

         // multi select choice lists
        if ($agilityAttrType == '2') {
            if (strpos($agilityAttrValue, '[') !== false) {
                if (strpos($agilityAttrValue, ']') !== false) {
                    if (strpos($agilityAttrValue, ',') !== false) {
                        $backEndType = 'varchar';
                        $frontEndIn = 'multiselect';
                    } else {
                        if ($agilityAttrValue == '[Yes]' || $agilityAttrValue == '[No]') {
                            $frontEndIn = 'boolean';
                            $backEndType = 'int';
                        } else {
                            $backEndType = 'varchar';
                            $frontEndIn = 'select';
                        }
                    }
                }
            }
        }

        //date value
        if ($agilityAttrType == '3') {
            $backEndType = 'datetime';
            $frontEndIn = 'date';
        }

        //path value
        if ($agilityAttrType == '14') {
            $frontEndIn = 'text';
        }

        /** @var $installer \Magento\Catalog\Setup\CategorySetup */
        $installer = $this->objectManager->create('Magento\Catalog\Setup\CategorySetup');
        $entityTypeId = $installer->getEntityTypeId('catalog_product');

        $this->attributeObj->setData(
            [
                'attribute_code' => $cleanAttrName,
                'entity_type_id' => $entityTypeId,
                'is_global' => (\Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE),
                'is_user_defined' => 1,
                'frontend_input' => $frontEndIn,
                'is_unique' => 0,
                'is_required' => 0,
                'is_searchable' => 1,
                'is_visible_in_advanced_search' => 0,
                'is_comparable' => 0,
                'is_filterable' => 1,
                'is_filterable_in_search' => 0,
                'is_used_for_promo_rules' => 0,
                'is_html_allowed_on_front' => 1,
                'is_visible_on_front' => 1,
                'used_in_product_listing' => 1,
                'used_for_sort_by' => 0,
                'frontend_label' => [$frontLabel],
                'backend_type' => $backEndType
            ]
        );

        try {
            //will error if already exists
            $attribute = $this->attributeRepository->save($this->attributeObj);
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:createEavAttribute attribute save failed for {$cleanAttrName} with message {$e->getMessage()}");
            return;
        }

        $id = $attribute->getAttributeId();

        //assign attribute to its set

        $magentoCore = $agilityObject->getMagentoCore();
        $attributeSetName = $magentoCore->getAttributesetname();
        $attribSetId = null;

        if ($attributeSetName) {
            //try to find the name if it exists first
            $attribSetId = $this->getMagentoAttribSets($attributeSetName);
            //if not found, create a new set
            if (!$attribSetId) {
                $attribSetId = $this->createAttributeSet($attributeSetName, $entityTypeId);
            }
        }

        if ($attribSetId) {
            $installer->addAttributeToGroup('catalog_product', $attributeSetName, 'General', $id);
        } else {
            //assign to default if no set defined
            $skeletonId = $this->getDefaultAttributeSetId();
            $defaultAttribSet = $this->attributeSet->get($skeletonId);
            $defaultName = $defaultAttribSet->getAttributeSetName();
            $installer->addAttributeToGroup('catalog_product', $defaultName, 'General', $id);
        }

        // multi select choice lists - add new attribute values

        $inputType = $attribute->getFrontendInput();

        if ($inputType == 'select' || $inputType == 'multiselect') {
            $arrayValues = $this->checkArray($agilityAttrValue);
            foreach ($arrayValues as $oneValue) {
                $this->createNewAttributeOption($oneValue, $id);
            }
        }
    }

    /**
     * Convert Text
     * This method takes a text string and converts it to lower case, removes
     * non alpha-numeric characters, trims whitespace from the beginning of the
     * string and replaces any spaces with an underscore.
     *
     * @param string $string
     * @return string $string
     */
    public function convertText($string)
    {
        //Lower case everything
        $string = strtolower($string);
        //Make alphanumeric (removes all other characters)
        $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
        //trim whitespace from beginning of string
        $string = ltrim($string);
        //Convert whitespace to dash
        $string = str_replace(" ", "_", $string);

        return $string;
    }

    /**
     * Create front end label
     * This method takes a camel case label and converts it into a nice label
     * For example newAttributeValue will get a label of New Attribute Label
     *
     * @param string $string
     * @return string $string
     */
    public function createLabel($string)
    {
        //Put first letter upper case
        $string = ucfirst($string);
        //Convert dash to whitespace
        $string = str_replace("_", " ", $string);
        $string = str_replace("-", " ", $string);
        //should split camel case into separate words
        $string = preg_replace('/(?!^)[A-Z]{2,}(?=[A-Z][a-z])|[A-Z][a-z]|[0-9]{1,}/', ' $0', $string);

        return $string;
    }

    /**
     * Check Array method
     * Check to see if the string is actually an array of values - for a
     * multiple choice attribute
     * Return an array of values with the square brackets and any leading white
     * space removed.
     *
     * @param string $string
     * @return array
     */

    public function checkArray($string)
    {
        $arrayValues = [];
        //check if string is an array
        if (strpos($string, '[') !== false) {
            if (strpos($string, ']') !== false) {
                $arrayValues = explode(",", $string);
                $arrayValues = str_replace("[", "", $arrayValues);
                $arrayValues = str_replace("]", "", $arrayValues);
                $arrayValues = array_map('trim', $arrayValues);
            }
        }

        return $arrayValues;
    }

    /**
     * Clean Text method
     * This method takes a string and removes any square brackets.
     *
     * @param string $string
     * @return string $string
     */

    public function cleanText($string)
    {
        $string = str_replace("[", "", $string);
        $string = str_replace("]", "", $string);

        return $string;
    }

    /**
     * Check for Options method
     * This method gets the eav attribute and checks if it has any options.
     * For each option, get the value and see if it matches the agility value
     * passed in to the method. If no match is found, this means that we need to
     * add the agility value as an option value to the existing Magento
     * attribute.
     *
     * @param string $cleanAttrName
     * @param string $agilityAttrValue
     */

    protected function checkForOptions($cleanAttrName, $agilityAttrValue)
    {
        $attrib = $this->getAttribute($cleanAttrName);
        if ($attrib) {
            $id = $attrib->getAttributeId();
            $options = $attrib->getOptions();
            //if there are options on the attribute already -
            //check if we need to add new ones
            if ($options) {
                $optionExists = false;
                foreach ($options as $oneOption) {
                    $optValue = $oneOption->getValue();
                    $label = $oneOption->getLabel();
                    $so = $oneOption->getSortOrder();
                    //attribute option already exists
                    if ($label == $agilityAttrValue) {
                        $optionExists = true;
                    }
                }
                if (!$optionExists) {
                    /* new attribute option */
                    $this->createNewAttributeOption($agilityAttrValue, $id);
                }
            }
        }
    }

    /**
     * Create New Attribute Option method
     * This method sets a new option value on an existing attribute in Magento.
     *
     * @param string $agilityAttrValue
     * @param string $id
     */

    public function createNewAttributeOption($agilityAttrValue, $id)
    {
        try {
            $this->option->setValue($agilityAttrValue);
            $this->attributeOptionLabel->setStoreId(0);
            $this->attributeOptionLabel->setLabel($agilityAttrValue);
            $this->option->setLabel($this->attributeOptionLabel);
            $this->option->setStoreLabels([$this->attributeOptionLabel]);
            $this->option->setSortOrder(0);
            $this->option->setIsDefault(false);
            $this->attributeOptionManagement->add('catalog_product', $id, $this->option);
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:createNewAttributeOption create option failed for {$agilityAttrValue} with message {$e->getMessage()}");
        }

    }

    /**
     * Get Option Label method
     * This method gets the option label value on an existing Magento attribute.
     *
     * @param string $attrName
     * @param string $attrOptionValue
     * @return string
     */

    protected function getOptionLabel($attrName, $attrOptionValue)
    {
        $optionLabel = null;
        $attrib = $this->getAttribute($attrName);
        if ($attrib) {
            $options = $attrib->getOptions();
            if ($options) {
                foreach ($options as $oneOption) {
                    $optValue = $oneOption->getValue();
                    if ($optValue == $attrOptionValue) {
                        //this is the option label name value
                        $optionLabel = $oneOption->getLabel();
                        return $optionLabel;
                    }
                }
            }
        }

        return $optionLabel;
    }

    /**
     * Get Option id method
     * This method returns the option id from a Magento attribute for an agility
     * attribute value. Used for setting the custom attribute value for a choice
     * list attribute.
     *
     * @param string $cleanAttrName
     * @param string $agilityAttrValue
     * @return string
     */

    protected function getOptionId($cleanAttrName, $agilityAttrValue)
    {
        $optValue = null;
        $attrib = $this->getAttribute($cleanAttrName);
        if ($attrib) {
            $options = $attrib->getOptions();
            if ($options) {
                foreach ($options as $oneOption) {
                    $optLabel = $oneOption->getLabel();
                    if ($optLabel == $agilityAttrValue) {
                        $optValue = $oneOption->getValue();
                        return $optValue;
                    }
                }
            }
        }

        return $optValue;
    }

    /**
     * Set Option ids method
     * This method sets the option ids for a custom attribute on a magento
     * product
     *
     * @param string $cleanAttrName
     * @param array $multiValue
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @return Magento\Catalog\Api\Data\ProductInterface
     */

    protected function setOptionIds($cleanAttrName, $multiValue, $magentoProduct)
    {
        $attrib = $this->getAttribute($cleanAttrName);
        if ($attrib) {
            $customAttrArray = [];
            foreach ($multiValue as $oneValue) {
                $options = $attrib->getOptions();
                if ($options) {
                    foreach ($options as $oneOption) {
                        $optLabel = $oneOption->getLabel();
                        if ($optLabel == $oneValue) {
                            $optValue = $oneOption->getValue();
                            array_push($customAttrArray, $optValue);
                        }
                    }
                }
            }
        }

        if ($customAttrArray) {
            $magentoProduct->setCustomAttribute($cleanAttrName, implode(',', $customAttrArray));
        }

        return $magentoProduct;
    }

    /**
     * Remove Links method
     * This method sets an empty array of product links on the magento product,
     * effectively removing any product links
     *
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @return Magento\Catalog\Api\Data\ProductInterface
     */

    protected function removeLinks($magentoProduct)
    {
        //remove links
        $magentoProduct->setProductLinks([]);
        $magentoProduct->setTypeId('simple');
        $sku = $magentoProduct->getSku();

        try {
            $id = $this->productLoader->save($magentoProduct);
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:removeLinks product save 
            		  failed for {$sku} with message {$e->getMessage()}");
        }

        return $magentoProduct;
    }

    /**
     * Check For Products And Options method
     * This method processes all the products and options on the agility export
     * xml file
     *
     * @param Agility\Import\Api\Data\ExportInterface $agilityExport
     */

    protected function checkForProductsAndOptions($agilityExport)
    {
        $optionIds = [];
        $options = [];

        $agilityProduct = $agilityExport->getProduct();
        if (!$agilityProduct) {
            $agilityProducts = $agilityExport->getProducts();
            if ($agilityProducts) {
                foreach ($agilityProducts as $oneProduct) {
                    $attribute = $oneProduct->getAttribute();
                    if (!$attribute) {
                        $attributes = $oneProduct->getAttributes();
                        foreach ($attributes as $oneAttribute) {
                            $this->checkAgilityAttributes($oneAttribute, $oneProduct);
                        }
                    } else {
                        $this->checkAgilityAttributes($attribute, $oneProduct);
                    }
                    //get the options on the product and check them for attributes
                    $option = $oneProduct->getOption();

                    if (!$option) {
                        $productoptions = $oneProduct->getOptions();
                        if ($productoptions) {
                            foreach ($productoptions as $oneproductOption) {
                                $attribute = $oneproductOption->getAttribute();
                                $this->checkAgilityAttributes($attribute, $oneproductOption);
                            }
                        }
                    } else { //one option
                        $attribute = $option->getAttribute();
                        $this->checkAgilityAttributes($attribute, $option);
                    }
                    $result = $this->createProduct($oneProduct, null);
                }
            } else {
                //check for options
                $option = $agilityExport->getOption();
                if (!$option) {
                    $options = $agilityExport->getOptions();
                    if ($options) {
                        foreach ($options as $oneOption) {
                            $attribute = $oneOption->getAttribute();
                            if (!$attribute) {
                                $attributes = $oneOption->getAttributes();
                                foreach ($attributes as $oneAttribute) {
                                    $this->checkAgilityAttributes($oneAttribute, $oneOption);
                                }
                            } else {
                                $this->checkAgilityAttributes($attribute, $oneOption);
                            }
                            $id = $this->checkOption($oneOption, null);
                            $agilityId = $oneOption->getAgilityId();
                            $parentId = $this->getParentId($agilityId, 'option', false);
                            if ($id) {
                                array_push($optionIds, $id);
                            }
                        }
                    }
                } else { //one option
                    $attribute = $option->getAttribute();
                    if (!$attribute) {
                        $attributes = $option->getAttributes();
                        foreach ($attributes as $oneAttribute) {
                            $this->checkEavAttribute($oneAttribute, $option);
                        }
                    } else {
                        $this->checkEavAttribute($attribute, $option);
                    }
                    //create option with no category
                    $id = $this->checkOption($option, null);
                    if ($id) {
                        $optionIds[] = $id;
                        $options[] = $option;
                        $agilityId = $option->getAgilityId();
                        if ($agilityId) {
                            $parentId = $this->getParentId($agilityId, 'option', false);
                        }
                    }
                }
            }
        } else { //one product
            $attribute = $agilityProduct->getAttribute();
            if (!$attribute) {
                $attributes = $agilityProduct->getAttributes();
                if ($attributes) {
                    foreach ($attributes as $oneAttribute) {
                        $this->checkEavAttribute($oneAttribute, $agilityProduct);
                    }
                }
            } else {
                $this->checkEavAttribute($attribute, $agilityProduct);
            }

            $option = $agilityProduct->getOption();
            if (!$option) {
                $productOptions = $agilityProduct->getOptions();
                if ($productOptions) {
                    foreach ($productOptions as $oneProductOption) {
                        $attribute = $oneProductOption->getAttribute();
                        $this->checkAgilityAttributes($attribute, $oneProductOption);
                    }
                }
            } else { //one variant
                $attribute = $option->getAttribute();
                $this->checkAgilityAttributes($attribute, $option);
            }
            $result = $this->createProduct($agilityProduct, null);
        }

        //for option/s only get parent and link it
        if ($options) {
            $magentoParentProduct = $this->productLoader->getById($parentId);
            if ($magentoParentProduct) {
                $magentoParentProduct = $this->createLinkToSimpleProducts($optionIds, $magentoParentProduct, $options);
            }
            try {
                $id = $this->productLoader->save($magentoParentProduct);
            } catch (\Exception $e) {
                $this->logger->info("AgilityImport:checkForProductsAndOptions parent product save failed for product id {$parentId} with message {$e->getMessage()}");
            }
        }
    }

    /**
     * Check For Attributes to Delete method
     * This method gets the attribute on the agility product and compares them
     * to the custom attributes on the equivalent Magento Product
     * It ignores any default attributes on the Magento product.
     * If an attribute is on the Magento product that is not on the agility
     * product, it is assumed that the attribute should be removed from the
     * Magento product (via the deleteAttribute method).
     *
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     */

    protected function checkAttributesToDelete($agilityProduct, $magentoProduct)
    {
        $newCodes = []; //holds all current attributes coming in on product

        $attribute = $agilityProduct->getAttribute();
        if (!$attribute) {
            $attributes = $agilityProduct->getAttributes();
            if (!$attributes) { //no attributes to check
                return;
            }
        } else {
            $attributes[] = $attribute;
        }
        foreach ($attributes as $oneAttribute) {
            $attrName = $oneAttribute->getName();
            $cleanAttrName = $this->convertText($attrName);
            array_push($newCodes, $cleanAttrName);
        }

        //this section looks for deleted attributes
        $existingAttributes = $magentoProduct->getCustomAttributes();
        $existingCodes = [];

        foreach ($existingAttributes as $existingAttribute) {
            $existingCode = $existingAttribute->getAttributeCode();
            if ($existingCode != 'category_ids' && $existingCode != 'options_container'
                    && $existingCode != 'required_options' && $existingCode != 'has_options'
                    && $existingCode != 'url_key' && $existingCode != 'tax_class_id'
                    && $existingCode != 'agilityid') {
                //the existing code is not in the agility extract - this is a delete
                if (!in_array($existingCode, $newCodes)) {
                    $object = $magentoProduct->getResource();
                    $attribute = $object->getAttribute($existingCode);
                    $connection = $object->getConnection();
                    $this->deleteAttribute($magentoProduct, $attribute, $connection);
                }
            }
        }
    }

    /**
     *
     * Delete Url Rewrite method
     * This method deletes the entity record from the url_rewrite table
     * This is done as a tidy up method when deleting a product or category
     * Leaving a record on this table can create an issue when recreating the
     * same product or category.
     *
     * @param \Magento\Framework\DB\Adapter\AdapterInterface $connection
     * @param string $id
     */
    protected function deleteUrlRewrite($connection, $id)
    {
        $table = 'url_rewrite';
        $field = 'entity_id';
        $where = $connection->quoteInto($field . '=?', $id);

        $connection->beginTransaction();

        try {
            $select = $connection->select()->from($table)->where($where);
            $connection->delete($table, $where);
            $connection->commit();
        } catch (\Exception $e) {
            $connection->rollback();
            $this->logger->info("AgilityImport:deleteUrlRewrite failed for {$table}, {$where} with message {$e->getMessage()}");
        }
    }

    /**
     *
     * Delete Attribute method
     * This method deletes an attribute on a product
     * I couldn't get this to happen through the API so had to do a direct table
     * update.
     *
     * @param \Magento\Framework\DataObject $object
     * @param AbstractAttribute $attribute
     * @param \Magento\Framework\DB\Adapter\AdapterInterface $connection
     */
    public function deleteAttribute(\Magento\Framework\DataObject $object, $attribute, $connection)
    {
        $backend = $attribute->getBackend();
        $table = $backend->getTable();
        $entity = $attribute->getEntity();
        $row = $this->getAttributeRow($entity, $object, $attribute);

        $whereArr = [];
        foreach ($row as $field => $value) {
            $whereArr[] = $connection->quoteInto($field . '=?', $value);
        }
        $where = implode(' AND ', $whereArr);

        $connection->beginTransaction();

        try {
            $select = $connection->select()->from($table, 'value_id')->where($where);
            $connection->delete($table, $where);
            $connection->commit();
        } catch (\Exception $e) {
            $connection->rollback();
            $this->logger->info("AgilityImport:deleteAttribute failed for
                {$table}, {$where} with message {$e->getMessage()}");
        }
    }

    /**
     * Return attribute row to prepare where statement
     *
     * @param \Magento\Framework\DataObject $entity
     * @param \Magento\Framework\DataObject $object
     * @param \Magento\Eav\Model\Entity\Attribute\AbstractAttribute $attribute
     * @return array
     */
    protected function getAttributeRow($entity, $object, $attribute)
    {
        $data = [
                'attribute_id' => $attribute->getId(),
                $entity->getLinkField() => $object->getData($entity->getLinkField()),
        ];

        if (!$object->getResource()->getEntityTable()) {
            $data['entity_type_id'] = $entity->getTypeId();
        }

        return $data;
    }

    /**
     *
     * Check for Relations method
     * This method checks for relations on a product
     *
     * @param Agility\Import\Api\Data\ExportInterface $agilityExport
     */

    protected function checkForRelations($agilityExport)
    {

        $agilityProduct = $agilityExport->getProduct();
        //process relations for each product (no category)
        if (!$agilityProduct) {
            $agilityProducts = $agilityExport->getProducts();
            if ($agilityProducts) {
                foreach ($agilityProducts as $oneProduct) {
                    $result = $this->processRelations($oneProduct);
                }
            }
        } else { //one product all on its own - aaaw
            $result = $this->processRelations($agilityProduct);
        }
    }

    /**
     * Retrieve entity type based on given code.
     *
     * @param string $entityTypeCode
     * @return \Magento\Eav\Model\Entity\Type|null
     */
    protected function getEntityTypeByCode($entityTypeCode)
    {
        /** @var \Magento\Eav\Model\Entity\Type $entityType */
        $entityType = $this->objectManager->create('Magento\Eav\Model\Config')
        ->getEntityType($entityTypeCode);

        return $entityType;
    }

    /**
     * Retrieve default attribute set id for products
     *
     * @return string
     */

    protected function getDefaultAttributeSetId()
    {
        $skeletonId = null;

        $entityType = $this->getEntityTypeByCode('catalog_product');
        $skeletonId = $entityType->getDefaultAttributeSetId();

        return $skeletonId;
    }

    /**
     * Create a new product attribute set, based on the default attribute set
     *
     * @param string $attributeSetName
     * @param string $entityTypeId
     * @return string
     */

    protected function createAttributeSet($attributeSetName, $entityTypeId)
    {
        $attribSetId = null;

        $attributeSet = $this->objectManager->create('\Magento\Eav\Api\Data\AttributeSetInterface');
        $attributeSet->setAttributeSetName($attributeSetName);
        $attributeSet->setEntityTypeId($entityTypeId);
        $attributeSetManagement = $this->objectManager->create('Magento\Eav\Api\AttributeSetManagementInterface');

        $skeletonId = $this->getDefaultAttributeSetId();

        if ($skeletonId) {
            $attributeSet = $attributeSetManagement->create($entityTypeId, $attributeSet, $skeletonId);
        }
        try {
            $attributeSet = $this->attributeSet->save($attributeSet);
            $attribSetId = $attributeSet->getAttributeSetId();
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:createAttributeSet attribute set save failed for
                {$attributeSetName} with message {$e->getMessage()}");
        }

        return $attribSetId;
    }

    /**
     * Look up a product by Sku
     *
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @return  Agility\Import\Api\Data\ProductInterface
     */
    protected function getProductBySku($agilityProduct)
    {
        //this should be an existing product - need to get it first
        $magentoCore = $agilityProduct->getMagentoCore();
        $sku = $magentoCore->getSku();
        $magentoProduct = null;

        try {
            $magentoProduct = $this->productLoader->get($sku);
            return $magentoProduct;
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:getProductBySku product get failed for 
                {$sku} with message {$e->getMessage()}");
        }
    }

    /**
     * Update the product category table
     * I couldn't do this through the API so resorted to a direct table update
     * It is required for move of products so that they can be assigned a new
     * parent.
     *
     * @param string $oldParentId
     * @param string $newParentId
     * @param string $productId
     */
    protected function updateProductCategory($oldParentId, $newParentId, $productId)
    {
        $this->attributeResource = $this->objectManager->
            create('Magento\Catalog\Model\ResourceModel\Attribute');
        $connection = $this->attributeResource->getConnection();

        if ($productId != null && $oldParentId != null && $newParentId !=null) {
            try {
                $table = 'catalog_category_product';
                $where = ("`product_id`={$productId} AND `category_id`={$oldParentId}");
                $bind = ['category_id' => new \Zend_Db_Expr((int)$newParentId)];
                $connection->update($table, $bind, $where);
            } catch (\Exception $e) {
                $this->logger->info("updateProductCategory:update product category 
                		   failed message is {$e->getMessage()}");
            }
        }
    }

    /**
     * Insert into the product category table
     *
     * I couldn't do this through the API so resorted to a direct table update
     * It is required for link of products so that they can be assigned to a new
     * parent.
     *
     * @param string $newParentId
     * @param string $productId
     */

    protected function insertProductCategory($newParentId, $productId)
    {
        $this->attributeResource = $this->objectManager->
            create('Magento\Catalog\Model\ResourceModel\Attribute');
        $connection = $this->attributeResource->getConnection();

        if ($newParentId != null && $productId != null) {
            try {
                $table = 'catalog_category_product';
                $bind = [
                        'category_id' => new \Zend_Db_Expr((int)$newParentId),
                        'product_id' => new \Zend_Db_Expr((int)$productId),
                        'position' => new \Zend_Db_Expr(1)
                ];

                $connection->insert($table, $bind);
            } catch (\Exception $e) {
                $this->logger->info("AgilityImport:insertProductCategory: product category insert 
                		failed message is {$e->getMessage()}");
            }
        }
    }

    /**
     * Delete from the product category table
     *
     * I couldn't do this through the API so resorted to a direct table update
     * It is required for unlink of products so that they can be removed from a parent
     *
     * @param string $parentId
     * @param string $productId
     */
    protected function deleteProductCategory($parentId, $productId)
    {
        $this->attributeResource = $this->objectManager->create('Magento\Catalog\Model\ResourceModel\Attribute');
        $connection = $this->attributeResource->getConnection();

        if ($productId != null && $parentId != null) {
            try {
                $table = 'catalog_category_product';
                $where = ("`product_id`={$productId} AND `category_id`={$parentId}");
                $connection->delete($table, $where);
            } catch (\Exception $e) {
                $this->logger->info("AgilityImport:deleteProductCategory: product category delete
                		failed message is {$e->getMessage()}");
            }
        }
    }

    /**
     * Get agility object id
     *
     * Get the last part of the agilityid path (after the last colon) -
     * this is the agility object id.
     *
     * @param string $agilityidPath
     * @return string
     */

    protected function getAgilityObjectId($agilityidPath)
    {
        $objectId = null;
        $colonPos = strrpos($agilityidPath, ":");// find the last colon separator
        $colonPos++;
        $endPos = strlen($agilityidPath); //get length of string
        $objectId = substr($agilityidPath, $colonPos, $endPos);

        return $objectId;
    }

    /**
     * Remove product links
     *
     * Remove links to simple products from the parent product
     * Called from removeParentOptions
     *
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @param string $removeId
     * @return Magento\Catalog\Api\Data\ProductInterface
     */

    protected function removeProductLinks($magentoProduct, $removeId)
    {
        $optionsFactory = $this->objectManager->create(Factory::class);
        $extensionConfigurableAttributes = $magentoProduct->getExtensionAttributes();
        $existingOptionIds = $extensionConfigurableAttributes->getConfigurableProductLinks();
        if ($existingOptionIds) {
            if (in_array($removeId, $existingOptionIds)) {
                $optionIds = array_diff($existingOptionIds, [$removeId]);
            }
            $extensionConfigurableAttributes->setConfigurableProductLinks($optionIds);
            $magentoProduct->setExtensionAttributes($extensionConfigurableAttributes);
            $existingOptionIds = $extensionConfigurableAttributes->getConfigurableProductLinks();
            if (!$existingOptionIds) { //no options left on product so it's not configurable any more
                $magentoProduct->setVisibility(\Magento\Catalog\Model\Product\Visibility::VISIBILITY_NOT_VISIBLE);
                $magentoProduct->setTypeId('simple');
            }
        } else { //no options left on product so it's not configurable any more
            $magentoProduct->setVisibility(\Magento\Catalog\Model\Product\Visibility::VISIBILITY_NOT_VISIBLE);
            $magentoProduct->setTypeId('simple');
        }

        return $magentoProduct;
    }

    /**
     * Add parent options
     * When linking a variant to a new parent object, need to get the existing
     * Magento attributes on the variant (simple product) and set them on the
     * agility product. This is so that when the link to simple product method
     * is called, it has the attributes on the agility product, otherwise this
     * method fails.
     *
     * @param string $agilityId
     * @param string $productId
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @param boolean $isLink
     * @param Magento\Catalog\Api\Data\ProductInterface $magentoProduct
     * @return Magento\Catalog\Api\Data\ProductInterface
     */

    protected function addParentOptions($agilityId, $productId, $agilityProduct, $isLink, $magentoProduct)
    {
        $optionIds[] = $productId;
        $newProductParentId = $this->getParentId($agilityId, 'option', false);
        $attribArray = [];

        //for links, need to get the attributes on the existing magento product
        //as they are not passed in xml
        if ($isLink) {
            $existingAttributes = $magentoProduct->getCustomAttributes();
            foreach ($existingAttributes as $existingAttribute) {
                $existingCode = $existingAttribute->getAttributeCode();
                if ($existingCode != 'category_ids' && $existingCode != 'options_container'
                        && $existingCode != 'required_options' && $existingCode != 'has_options'
                        && $existingCode != 'url_key' && $existingCode != 'tax_class_id'
                        && $existingCode != 'agilityid') {
                    $attributeObj = $this->objectManager->create('\Agility\Import\Api\Data\AttributeInterface');
                    $attributeObj->setName($existingCode);
                    $existingValue = $existingAttribute->getValue();
                    $attrLabel = $this->getOptionLabel($existingCode, $existingValue);
                    if ($attrLabel) {
                        $attributeObj->setValue($attrLabel);
                    } else {
                        $attributeObj->setValue($existingValue);
                    }
                    array_push($attribArray, $attributeObj);
                }
            }
            $agilityProduct->setAttributes($attribArray);
        }

        if ($newProductParentId) {
            $parentProduct = $this->productLoader->getById($newProductParentId);
        }

        //need to get the parent magento product of the option
        $options[] = $agilityProduct;
        if ($parentProduct) {
            $parentProduct = $this->createLinkToSimpleProducts($optionIds, $parentProduct, $options);
        }

        try {
            //save new parent configs
            $id = $this->productLoader->save($parentProduct);
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:addParentOptions product save failed for option parent message is {$e->getMessage()}");
        }
    }

    /**
     * Remove parent options
     * Remove the option from the old parent id for product moves and unlinks.
     * Save the old parent product with the new configuration.
     *
     * @param string $type
     * @param Agility\Import\Api\Data\ProductInterface $agilityProduct
     * @param string $productId
     */

    protected function removeParentOptions($type, $agilityProduct, $productId)
    {
        // get the product loader on the oldparent id and remove the option from
        //custom attributes
        //old parent - need the grandparent of this
        $parentAgilityId = $agilityProduct->getParentAgilityId();
        //get this product and update custom attrs
        $oldProductParentId = $this->getAgilityObjectId($parentAgilityId);
        $oldProductId = $this->getObjectById($oldProductParentId, $type);
        if ($oldProductId) {
            $oldProduct = $this->productLoader->getById($oldProductId);
            //remove product from its old parent
            $this->removeProductLinks($oldProduct, $productId);
        }

        try {
            //save old parent configs
            $id = $this->productLoader->save($oldProduct);
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:removeParentOptions product save 
            		failed for option old parent message is {$e->getMessage()}");
        }
    }

    /**
     * Get attribute
     * Get an eav attribute from the attribute Repository
     *
     * @param string $attrName
     * @return \Magento\Catalog\Api\ProductAttributeRepositoryInterface
     */

    protected function getAttribute($attrName)
    {
        try {
            $eavAttrib = $this->attributeRepository->get('4', $attrName);
        } catch (\Exception $e) {
            $this->logger->info("AgilityImport:getAttribute failed for 
            {$attrName} with message {$e->getMessage()}");
            return;
        }

        return $eavAttrib;
    }
}
