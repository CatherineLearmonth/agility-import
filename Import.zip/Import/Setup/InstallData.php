<?php
/**
 * Copyright � 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Agility\Import\Setup;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface
{

    /**
     * EAV setup factory
     *
     * @var EavSetupFactory
     */
    private $eavSetupFactory;

    /**
     * Init
     *
     * @param CategorySetupFactory $categorySetupFactory
     * @param EavSetupFactory $eavSetupFactory
     */
    public function __construct(EavSetupFactory $eavSetupFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        /**
         * Add attributes to the eav/attribute - copied from vendor code
         */
         $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
         $eavSetup->addAttribute(
         \Magento\Catalog\Model\Category::ENTITY,
         'agilityid',
         [
         'type' => 'varchar',
         'label' => 'Agility Id',
         'input' => 'textarea',
         'required' => false,
         'sort_order' => 5,
  //     'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE, //makes the attribute visible on the product
         'group' => 'General',
         'is_used_in_grid' => false,
         'is_visible_in_grid' => false,
         'is_filterable_in_grid' => false
         ]
         );

         $eavSetup->addAttribute(
         \Magento\Catalog\Model\Product::ENTITY,
         'agilityid',
         [
         'type' => 'varchar',
         'label' => 'Agility Id',
         'input' => 'textarea',
         'required' => false,
         'sort_order' => 5,
   //    'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
         'group' => 'General',
         'is_used_in_grid' => false,
         'is_visible_in_grid' => false,
         'is_filterable_in_grid' => false
         ]
         );

        $setup->endSetup();

    }
}
