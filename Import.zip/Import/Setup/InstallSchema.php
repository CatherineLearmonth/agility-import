<?php

namespace Agility\Import\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface
{
    public function install(
        SchemaSetupInterface $setup
    ) {
        $installer = $setup;
        $installer->startSetup();
        $installer->endSetup();
    }
}
